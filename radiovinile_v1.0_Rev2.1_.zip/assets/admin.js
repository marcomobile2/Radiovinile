/* ════════════════════════════════════════════════════
   RADIO VINILE — admin.js
   Pannello Admin: roadmap, changelog, gestione DJ
   Visibile solo agli utenti con ruolo admin
   Versione: v1.0 Rev 2.1
════════════════════════════════════════════════════ */

const Admin = (() => {

  function init() {
    if (!Auth.isAdmin()) return;
    showAdminElements();
    loadRoadmap();
    loadChangelog();
  }

  function showAdminElements() {
    document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
  }

  async function loadRoadmap() {
    const container = document.getElementById('roadmap-list');
    if (!container) return;
    try {
      const res  = await Auth.authFetch('/roadmap');
      const data = await res.json();
      container.innerHTML = data.map(item => `
        <div class="roadmap-item">
          <div class="roadmap-title">${item.title}</div>
          ${item.description ? `<div class="roadmap-desc">${item.description}</div>` : ''}
          <div class="roadmap-footer">
            <span class="rm-badge rm-${item.priority}">${item.priority}</span>
            <span class="rm-badge rm-${item.status.replace('_','-')}">${item.status}</span>
            ${item.target_version ? `<span class="rm-target">→ ${item.target_version}</span>` : ''}
          </div>
        </div>
      `).join('');
    } catch (e) {
      container.innerHTML = renderDemoRoadmap();
    }
  }

  async function loadChangelog() {
    const container = document.getElementById('changelog-list');
    if (!container) return;
    try {
      const res  = await fetch(`${Auth.API}/changelog`);
      const data = await res.json();
      container.innerHTML = data.map(item => `
        <div class="changelog-item">
          <div class="cl-ver">v${item.version} — ${item.revision}</div>
          <div class="cl-date">${item.date}</div>
          <div class="cl-desc">${item.description}</div>
        </div>
      `).join('');
    } catch (e) {
      container.innerHTML = renderDemoChangelog();
    }
  }

  function renderDemoRoadmap() {
    const items = [
      { title: 'Icecast2 + Liquidsoap', desc: 'Installazione server streaming audio sul server Aruba.', priority: 'alta', status: 'in_sviluppo', target: 'v1.1' },
      { title: 'Separazione CSS/JS (Rev 1.4)', desc: 'Struttura file modulare con HTML, CSS e JS separati.', priority: 'alta', status: 'completata', target: 'v1.0' },
      { title: 'Viste per ruolo', desc: 'Interfacce diverse per visitatore, DJ e admin.', priority: 'alta', status: 'completata', target: 'v1.0' },
      { title: 'App React Native', desc: 'App mobile iOS/Android con background audio, chat, richieste.', priority: 'alta', status: 'idea', target: 'v2.0' },
      { title: 'Firebase Chat real-time', desc: 'Messaggi in tempo reale con Firebase Firestore.', priority: 'media', status: 'idea', target: 'v2.0' },
      { title: 'Integrazione WhatsApp + Telegram', desc: 'Ricezione richieste brani via WhatsApp Business e bot Telegram.', priority: 'media', status: 'idea', target: 'v1.3' },
      { title: 'Podcast RSS Feed', desc: 'Feed RSS automatico per puntate pubblicate.', priority: 'media', status: 'idea', target: 'v1.3' },
    ];
    return items.map(i => `
      <div class="roadmap-item">
        <div class="roadmap-title">${i.title}</div>
        <div class="roadmap-desc">${i.desc}</div>
        <div class="roadmap-footer">
          <span class="rm-badge rm-${i.priority}">${i.priority}</span>
          <span class="rm-badge rm-${i.status.replace('_','-')}">${i.status.replace('_',' ')}</span>
          <span class="rm-target">→ ${i.target}</span>
        </div>
      </div>
    `).join('');
  }

  function renderDemoChangelog() {
    const items = [
      { ver: 'v1.0 — Rev 1.5', date: '23 Marzo 2026', desc: 'Player audio funzionante con fix autoplay. Stream URL su radiovinile.online/stream. Indicatore caricamento (⏳). Status stream in version bar. Version bar con revisione a piè di pagina. Liquidsoap come servizio systemd. CORS headers in Caddy. Script Liquidsoap pronto per playlist MP3.' },
      { ver: 'v1.0 — Rev 1.4', date: '22 Marzo 2026', desc: 'Separazione HTML/CSS/JS. Viste per ruolo (visitatore/DJ/admin). Admin-only: roadmap e changelog visibili solo all\'admin. File modulari: auth.js, player.js, chat.js, dj.js, admin.js, app.js.' },
      { ver: 'v1.0 — Rev 1.3', date: '22 Marzo 2026', desc: 'Login DJ collegato all\'API reale. Rimosso demo mode. Dominio radiovinile.online attivo. Icecast2 attivo sulla porta 8950.' },
      { ver: 'v1.0 — Rev 1.2', date: '22 Marzo 2026', desc: 'Login JWT, database SQLite con 8 tabelle, backend FastAPI con 15 endpoint. Tab Roadmap e Changelog nel pannello DJ.' },
      { ver: 'v1.0 — Rev 1.1', date: '22 Marzo 2026', desc: 'Prima versione ufficiale. Sito pubblico con player, palinsesto, chat. Pannello DJ con tab Chat, Richieste, Microfono, Telefonate. Layout responsive.' },
    ];
    return items.map(i => `
      <div class="changelog-item">
        <div class="cl-ver">${i.ver}</div>
        <div class="cl-date">${i.date}</div>
        <div class="cl-desc">${i.desc}</div>
      </div>
    `).join('');
  }

  return { init };

})();
