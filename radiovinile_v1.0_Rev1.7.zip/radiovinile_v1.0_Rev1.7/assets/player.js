/* ════════════════════════════════════════════════════
   RADIO VINILE — player.js
   Versione: v1.0 Rev 1.7
   Fix: bottoni semplificati, cuore con login Google/Facebook,
        avviso visibile quando stream cade
════════════════════════════════════════════════════ */

const Player = (() => {

  const STREAM_URL    = 'https://radiovinile.online/stream';
  const POLL_INTERVAL = 10000;

  let _audio    = null;
  let _playing  = false;
  let _loading  = false;
  let _liked    = false;
  let _nowPlaying = { title: 'Radio Vinile', artist: 'In onda' };

  function init() {
    _audio = document.getElementById('radio-audio');

    _audio.addEventListener('playing', () => {
      _loading = false; _playing = true;
      updatePlayBtn(); setVinylSpin(true); setStreamStatus(true);
      hideStreamError();
    });
    _audio.addEventListener('pause', () => {
      _playing = false; updatePlayBtn(); setVinylSpin(false);
    });
    _audio.addEventListener('waiting', () => {
      _loading = true; updatePlayBtn();
    });
    _audio.addEventListener('error', () => {
      _loading = false; _playing = false;
      updatePlayBtn(); setVinylSpin(false);
      setStreamStatus(false);
      showStreamError();
    });
    _audio.addEventListener('stalled', () => {
      showStreamError('Connessione lenta — riconnessione in corso...');
    });

    // Bottoni player
    document.getElementById('btn-play').addEventListener('click', togglePlay);
    document.getElementById('hero-play-btn').addEventListener('click', () => {
      play();
      document.getElementById('player').scrollIntoView({ behavior: 'smooth' });
    });

    // Bottone cuore
    const likeBtn = document.getElementById('btn-like');
    if (likeBtn) likeBtn.addEventListener('click', handleLike);

    // Bottone condividi
    const shareBtn = document.getElementById('btn-share');
    if (shareBtn) shareBtn.addEventListener('click', handleShare);

    // Volume
    const volBar  = document.querySelector('.vol-bar');
    const volFill = document.getElementById('vol-fill');
    if (volBar) {
      volBar.addEventListener('click', e => {
        const pct = Math.max(0, Math.min(1, e.offsetX / volBar.offsetWidth));
        _audio.volume = pct;
        volFill.style.width = (pct * 100) + '%';
      });
    }

    fetchNowPlaying();
    setInterval(fetchNowPlaying, POLL_INTERVAL);
  }

  function play() {
    if (_loading) return;
    if (!_audio.src || _audio.src === window.location.href) {
      _audio.src = STREAM_URL;
    }
    _loading = true;
    updatePlayBtn();
    _audio.play().catch(err => {
      _loading = false; _playing = false;
      updatePlayBtn();
      showStreamError('Impossibile avviare lo stream. Riprova.');
    });
  }

  function pause() {
    _audio.pause();
    _playing = false; _loading = false;
    updatePlayBtn(); setVinylSpin(false); setStreamStatus(false);
  }

  function togglePlay() { _playing ? pause() : play(); }

  function updatePlayBtn() {
    let icon = _loading ? '⏳' : (_playing ? '⏸' : '▶');
    const btn = document.getElementById('btn-play');
    if (btn) btn.textContent = icon;
    const hero = document.getElementById('hero-play-btn');
    if (hero) hero.textContent = _playing ? '⏸ In ascolto' : '▶ Ascolta ora';
    const dj = document.getElementById('dj-play-btn');
    if (dj) dj.textContent = _playing ? '⏸' : '▶';
  }

  function setVinylSpin(running) {
    const state = running ? 'running' : 'paused';
    ['hero-vinyl','player-disc','on-air-disc'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.animationPlayState = state;
    });
  }

  function setStreamStatus(online) {
    const el = document.getElementById('ver-stream-status');
    if (!el) return;
    el.textContent = online ? '🔴 In onda' : '⏸ Stream offline';
    el.style.color  = online ? 'var(--live)' : 'var(--t3)';
  }

  function showStreamError(msg) {
    let errEl = document.getElementById('stream-error-banner');
    if (!errEl) {
      errEl = document.createElement('div');
      errEl.id = 'stream-error-banner';
      errEl.className = 'stream-error-banner';
      const playerWrap = document.querySelector('.player-wrap');
      if (playerWrap) playerWrap.insertBefore(errEl, playerWrap.firstChild);
    }
    errEl.textContent = msg || '⚠️ Stream non disponibile — riprova tra qualche secondo';
    errEl.classList.remove('hidden');
  }

  function hideStreamError() {
    const errEl = document.getElementById('stream-error-banner');
    if (errEl) errEl.classList.add('hidden');
  }

  // ── CUORE / PREFERITI ──
  function handleLike() {
    const listener = ListenerAuth.getUser();
    if (!listener) {
      // Non loggato — mostra modal login
      document.getElementById('listener-login-modal').classList.remove('hidden');
      return;
    }
    // Loggato — salva il brano
    toggleLike();
  }

  function toggleLike() {
    _liked = !_liked;
    const btn = document.getElementById('btn-like');
    if (!btn) return;
    if (_liked) {
      btn.textContent = '❤️';
      btn.classList.add('liked');
      ListenerAuth.saveFavorite(_nowPlaying);
      App.showToast(`❤️ "${_nowPlaying.title}" salvato nei preferiti!`);
    } else {
      btn.textContent = '♥';
      btn.classList.remove('liked');
      ListenerAuth.removeFavorite(_nowPlaying);
      App.showToast(`Rimosso dai preferiti`);
    }
  }

  function setLikedState(liked) {
    _liked = liked;
    const btn = document.getElementById('btn-like');
    if (!btn) return;
    btn.textContent = liked ? '❤️' : '♥';
    if (liked) btn.classList.add('liked');
    else btn.classList.remove('liked');
  }

  // ── CONDIVIDI ──
  function handleShare() {
    const np = _nowPlaying;
    const text = `Sto ascoltando "${np.title}" di ${np.artist} su Radio Vinile 📻`;
    if (navigator.share) {
      navigator.share({ title: 'Radio Vinile', text, url: 'https://radiovinile.online' });
    } else {
      navigator.clipboard.writeText(text + ' — https://radiovinile.online');
      App.showToast('Link copiato negli appunti!');
    }
  }

  async function fetchNowPlaying() {
    try {
      const res  = await fetch('https://api.radiovinile.online/api/sessions/current');
      const data = await res.json();
      const title  = data.title  || 'Radio Vinile';
      const artist = data.artist || 'In onda';
      const count  = data.listeners !== undefined ? data.listeners : '—';

      _nowPlaying = { title, artist };

      const set = (id, v) => { const e = document.getElementById(id); if(e) e.textContent = v; };
      set('player-title',    title);
      set('player-artist',   artist);
      set('live-strip-song', artist + ' — ' + title);
      set('listener-count',  count);
      set('oa-title',        title);
      set('oa-artist',       artist);

      // Aggiorna stato cuore in base ai preferiti salvati
      const listener = ListenerAuth.getUser();
      if (listener) {
        const favs = ListenerAuth.getFavorites();
        const isFav = favs.some(f => f.title === title && f.artist === artist);
        setLikedState(isFav);
      }
    } catch(_) {}
  }

  function getNowPlaying() { return _nowPlaying; }
  function isPlaying()     { return _playing; }

  return { init, play, pause, togglePlay, fetchNowPlaying, getNowPlaying, isPlaying, handleLike };

})();
