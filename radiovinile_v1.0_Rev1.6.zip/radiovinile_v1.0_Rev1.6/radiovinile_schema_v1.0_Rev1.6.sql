-- ================================================================================
-- RADIO VINILE — Schema Database SQLite
-- File: radiovinile.db
-- Versione: v1.0 Rev 1.2
-- ================================================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ────────────────────────────────────────
-- TABELLA: djs
-- Anagrafica DJ e credenziali di accesso
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS djs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    username     TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL,
    role         TEXT NOT NULL DEFAULT 'dj' CHECK(role IN ('admin','dj')),
    active       BOOLEAN NOT NULL DEFAULT 1,
    avatar       TEXT,
    bio          TEXT,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login   DATETIME
);

-- ────────────────────────────────────────
-- TABELLA: dj_sessions
-- Ogni sessione in onda (live o automatica)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dj_sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    dj_id           INTEGER REFERENCES djs(id),
    program_name    TEXT NOT NULL,
    program_desc    TEXT,
    date            DATE NOT NULL,
    time_start      DATETIME,
    time_end        DATETIME,
    is_live         BOOLEAN NOT NULL DEFAULT 1,
    status          TEXT NOT NULL DEFAULT 'scheduled'
                    CHECK(status IN ('scheduled','on_air','ended','cancelled')),
    listeners_peak  INTEGER DEFAULT 0,
    listeners_avg   INTEGER DEFAULT 0,
    total_tracks    INTEGER DEFAULT 0,
    total_requests  INTEGER DEFAULT 0,
    notes           TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────
-- TABELLA: played_tracks
-- Brani suonati per ogni sessione
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS played_tracks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER NOT NULL REFERENCES dj_sessions(id),
    song_title   TEXT NOT NULL,
    song_artist  TEXT NOT NULL,
    song_year    INTEGER,
    song_album   TEXT,
    played_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    duration_sec INTEGER,
    source       TEXT DEFAULT 'digital'
                 CHECK(source IN ('vinyl','digital','request','jingle')),
    request_id   INTEGER REFERENCES song_requests(id),
    notes        TEXT
);

-- ────────────────────────────────────────
-- TABELLA: song_requests
-- Richieste brani dagli ascoltatori
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS song_requests (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       INTEGER REFERENCES dj_sessions(id),
    requester_name   TEXT NOT NULL,
    requester_contact TEXT,
    origin           TEXT NOT NULL DEFAULT 'web'
                     CHECK(origin IN ('web','chat','telefonica','whatsapp',
                                      'telegram','app','email','altro')),
    song_title       TEXT NOT NULL,
    song_artist      TEXT,
    dedication       TEXT,
    status           TEXT NOT NULL DEFAULT 'pending'
                     CHECK(status IN ('pending','accepted','played','skipped')),
    requested_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    played_at        DATETIME,
    dj_note          TEXT
);

-- ────────────────────────────────────────
-- TABELLA: recordings
-- Registrazioni audio sessioni e telefonate
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS recordings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id    INTEGER REFERENCES dj_sessions(id),
    type          TEXT NOT NULL DEFAULT 'full_session'
                  CHECK(type IN ('full_session','phone_call','highlight','segment')),
    filename      TEXT NOT NULL,
    filepath      TEXT NOT NULL,
    duration_sec  INTEGER,
    size_mb       REAL,
    phone_number  TEXT,
    call_id       INTEGER REFERENCES song_requests(id),
    published     BOOLEAN DEFAULT 0,
    published_title TEXT,
    published_desc  TEXT,
    published_at  DATETIME,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────
-- TABELLA: changelog
-- Storico versioni del progetto
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS changelog (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    version     TEXT NOT NULL,
    revision    TEXT NOT NULL,
    date        DATE NOT NULL,
    description TEXT NOT NULL,
    filename    TEXT,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────
-- TABELLA: roadmap
-- Feature e sviluppi futuri
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roadmap (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    title           TEXT NOT NULL,
    description     TEXT,
    priority        TEXT NOT NULL DEFAULT 'media'
                    CHECK(priority IN ('alta','media','bassa')),
    status          TEXT NOT NULL DEFAULT 'idea'
                    CHECK(status IN ('idea','approvata','in_sviluppo',
                                     'in_test','completata','annullata')),
    target_version  TEXT,
    assigned_to     TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at    DATETIME
);

-- ────────────────────────────────────────
-- TABELLA: backups
-- Registro backup file prodotti
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS backups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    filename    TEXT NOT NULL,
    version     TEXT NOT NULL,
    revision    TEXT NOT NULL,
    filepath    TEXT NOT NULL,
    size_kb     INTEGER,
    notes       TEXT,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ────────────────────────────────────────
-- INDICI per performance
-- ────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_sessions_date      ON dj_sessions(date);
CREATE INDEX IF NOT EXISTS idx_sessions_status    ON dj_sessions(status);
CREATE INDEX IF NOT EXISTS idx_tracks_session     ON played_tracks(session_id);
CREATE INDEX IF NOT EXISTS idx_tracks_played_at   ON played_tracks(played_at);
CREATE INDEX IF NOT EXISTS idx_requests_session   ON song_requests(session_id);
CREATE INDEX IF NOT EXISTS idx_requests_status    ON song_requests(status);
CREATE INDEX IF NOT EXISTS idx_recordings_session ON recordings(session_id);
CREATE INDEX IF NOT EXISTS idx_recordings_type    ON recordings(type);
CREATE INDEX IF NOT EXISTS idx_roadmap_status     ON roadmap(status);
CREATE INDEX IF NOT EXISTS idx_roadmap_priority   ON roadmap(priority);

-- ────────────────────────────────────────
-- DATI INIZIALI
-- ────────────────────────────────────────

-- DJ admin di default (password: RadioVinile2025! — da cambiare subito)
-- Hash bcrypt generato lato backend al primo avvio
INSERT OR IGNORE INTO djs (username, password_hash, display_name, role)
VALUES ('admin', 'CHANGEME_HASH', 'Admin', 'admin');

-- Changelog Rev 1.1
INSERT OR IGNORE INTO changelog (version, revision, date, description, filename)
VALUES (
    'v1.0', 'Rev1.1', '2026-03-22',
    'Prima versione ufficiale. Sito pubblico con player, palinsesto, chat. Pannello DJ con gestione brani, richieste, microfono, telefonate. Layout responsive mobile/desktop. Deploy su radiovinile.suimi.net.',
    'radiovinile_v1.0_Rev1.1.html'
);

-- Changelog Rev 1.2
INSERT OR IGNORE INTO changelog (version, revision, date, description, filename)
VALUES (
    'v1.0', 'Rev1.2', '2026-03-22',
    'Aggiunto sistema login DJ con autenticazione JWT. Creato database SQLite con tabelle: djs, dj_sessions, played_tracks, song_requests, recordings, changelog, roadmap, backups. Backend API Python/FastAPI. Registrazione sessioni audio completa. Gestione podcast/archivio.',
    'radiovinile_v1.0_Rev1.2.html'
);

-- Roadmap iniziale
INSERT OR IGNORE INTO roadmap (title, description, priority, status, target_version) VALUES
('Icecast2 + Liquidsoap', 'Installazione e configurazione server streaming audio sul server Aruba', 'alta', 'approvata', 'v1.1'),
('App React Native', 'App mobile iOS/Android con background audio, chat, richieste, archivio', 'alta', 'idea', 'v2.0'),
('Notifiche Push Firebase', 'Notifiche push quando il DJ va in onda o richiesta accettata', 'media', 'idea', 'v2.0'),
('Integrazione WhatsApp', 'Ricezione richieste brani via WhatsApp Business API', 'media', 'idea', 'v1.3'),
('Integrazione Telegram', 'Bot Telegram per richieste e chat', 'media', 'idea', 'v1.3'),
('Player con rewind', 'Possibilità di riascoltare gli ultimi 60 minuti dello stream', 'alta', 'approvata', 'v1.2'),
('Statistiche avanzate', 'Dashboard con grafici ascolti, richieste, picchi orari', 'bassa', 'idea', 'v1.4'),
('Podcast RSS feed', 'Feed RSS automatico per le puntate pubblicate su podcast', 'media', 'idea', 'v1.3');

-- ================================================================================
-- FINE SCHEMA
-- ================================================================================
