#!/usr/bin/env python3
"""
================================================================================
RADIO VINILE — Backend API
File: api.py
Versione: v1.0 Rev 1.2
================================================================================
Dipendenze: pip install fastapi uvicorn python-jose passlib bcrypt python-multipart
"""

import sqlite3, os, hashlib, secrets, json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import JWTError, jwt

# ── CONFIG ──────────────────────────────────────────────────────────────────
BASE_DIR    = Path("/opt/suimi/radiovinile")
DB_PATH     = BASE_DIR / "radiovinile.db"
REC_DIR     = BASE_DIR / "recordings"
BACKUP_DIR  = BASE_DIR / "backups"
SECRET_KEY  = os.environ.get("RV_SECRET", "radiovinile_secret_change_me_2025")
ALGORITHM   = "HS256"
TOKEN_EXPIRE_HOURS = 12

# Crea directory se non esistono
for d in [REC_DIR / "sessions", REC_DIR / "calls", BACKUP_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── APP ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="Radio Vinile API", version="1.0.2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_ctx  = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer(auto_error=False)

# ── DB ───────────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    """Inizializza il database con lo schema SQL."""
    schema_path = BASE_DIR / "radiovinile_schema.sql"
    if schema_path.exists():
        conn = get_db()
        with open(schema_path) as f:
            conn.executescript(f.read())
        conn.commit()
        conn.close()

# ── AUTH ─────────────────────────────────────────────────────────────────────
def create_token(data: dict) -> str:
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Token mancante")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Token non valido")

def get_current_dj(token_data: dict = Depends(verify_token)):
    db = get_db()
    dj = db.execute("SELECT * FROM djs WHERE id=? AND active=1",
                    (token_data.get("dj_id"),)).fetchone()
    db.close()
    if not dj:
        raise HTTPException(status_code=401, detail="DJ non trovato")
    return dict(dj)

def require_admin(dj = Depends(get_current_dj)):
    if dj["role"] != "admin":
        raise HTTPException(status_code=403, detail="Solo admin")
    return dj

# ── MODELLI ──────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class SessionCreate(BaseModel):
    program_name: str
    program_desc: Optional[str] = None
    date: str
    time_start: Optional[str] = None
    is_live: bool = True

class TrackCreate(BaseModel):
    session_id: int
    song_title: str
    song_artist: str
    song_year: Optional[int] = None
    song_album: Optional[str] = None
    duration_sec: Optional[int] = None
    source: str = "digital"
    request_id: Optional[int] = None

class RequestCreate(BaseModel):
    session_id: Optional[int] = None
    requester_name: str
    requester_contact: Optional[str] = None
    origin: str = "web"
    song_title: str
    song_artist: Optional[str] = None
    dedication: Optional[str] = None

class RequestUpdate(BaseModel):
    status: str
    dj_note: Optional[str] = None

class RoadmapCreate(BaseModel):
    title: str
    description: Optional[str] = None
    priority: str = "media"
    status: str = "idea"
    target_version: Optional[str] = None

class DJCreate(BaseModel):
    username: str
    password: str
    display_name: str
    role: str = "dj"

class RecordingPublish(BaseModel):
    published_title: str
    published_desc: Optional[str] = None

# ── ROUTES: AUTH ─────────────────────────────────────────────────────────────
@app.post("/api/auth/login")
def login(req: LoginRequest):
    db = get_db()
    dj = db.execute("SELECT * FROM djs WHERE username=? AND active=1",
                    (req.username,)).fetchone()
    if not dj or not pwd_ctx.verify(req.password, dj["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenziali non valide")
    db.execute("UPDATE djs SET last_login=? WHERE id=?",
               (datetime.utcnow(), dj["id"]))
    db.commit()
    db.close()
    token = create_token({"dj_id": dj["id"], "role": dj["role"],
                          "display_name": dj["display_name"]})
    return {
        "token": token,
        "dj_id": dj["id"],
        "display_name": dj["display_name"],
        "role": dj["role"]
    }

@app.post("/api/auth/change-password")
def change_password(data: dict, dj=Depends(get_current_dj)):
    db = get_db()
    current = db.execute("SELECT password_hash FROM djs WHERE id=?",
                         (dj["id"],)).fetchone()
    if not pwd_ctx.verify(data["old_password"], current["password_hash"]):
        raise HTTPException(status_code=400, detail="Password attuale errata")
    new_hash = pwd_ctx.hash(data["new_password"])
    db.execute("UPDATE djs SET password_hash=? WHERE id=?",
               (new_hash, dj["id"]))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: SESSIONI ─────────────────────────────────────────────────────────
@app.get("/api/sessions")
def get_sessions(limit: int = 20, offset: int = 0, dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute("""
        SELECT s.*, d.display_name as dj_name
        FROM dj_sessions s
        LEFT JOIN djs d ON s.dj_id = d.id
        ORDER BY s.date DESC, s.time_start DESC
        LIMIT ? OFFSET ?
    """, (limit, offset)).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/sessions/current")
def get_current_session():
    """Sessione attualmente in onda — pubblica."""
    db = get_db()
    row = db.execute("""
        SELECT s.*, d.display_name as dj_name
        FROM dj_sessions s
        LEFT JOIN djs d ON s.dj_id = d.id
        WHERE s.status = 'on_air'
        ORDER BY s.time_start DESC LIMIT 1
    """).fetchone()
    db.close()
    return dict(row) if row else {"status": "automatica"}

@app.post("/api/sessions")
def create_session(data: SessionCreate, dj=Depends(get_current_dj)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO dj_sessions (dj_id, program_name, program_desc, date,
                                  time_start, is_live, status)
        VALUES (?,?,?,?,?,?,'scheduled')
    """, (dj["id"], data.program_name, data.program_desc,
          data.date, data.time_start, data.is_live))
    db.commit()
    session_id = cur.lastrowid
    db.close()
    return {"id": session_id, "ok": True}

@app.put("/api/sessions/{session_id}/start")
def start_session(session_id: int, dj=Depends(get_current_dj)):
    db = get_db()
    db.execute("""UPDATE dj_sessions SET status='on_air', time_start=?
                  WHERE id=?""", (datetime.utcnow(), session_id))
    db.commit()
    db.close()
    return {"ok": True, "status": "on_air"}

@app.put("/api/sessions/{session_id}/end")
def end_session(session_id: int, dj=Depends(get_current_dj)):
    db = get_db()
    # Conta brani e richieste
    tracks = db.execute("SELECT COUNT(*) FROM played_tracks WHERE session_id=?",
                        (session_id,)).fetchone()[0]
    requests = db.execute("SELECT COUNT(*) FROM song_requests WHERE session_id=?",
                          (session_id,)).fetchone()[0]
    db.execute("""UPDATE dj_sessions
                  SET status='ended', time_end=?, total_tracks=?, total_requests=?
                  WHERE id=?""",
               (datetime.utcnow(), tracks, requests, session_id))
    db.commit()
    db.close()
    return {"ok": True, "status": "ended", "total_tracks": tracks}

@app.get("/api/sessions/{session_id}/tracks")
def get_session_tracks(session_id: int):
    """Brani di una sessione — pubblica (per archivio)."""
    db = get_db()
    rows = db.execute("""
        SELECT * FROM played_tracks
        WHERE session_id=? ORDER BY played_at ASC
    """, (session_id,)).fetchall()
    db.close()
    return [dict(r) for r in rows]

# ── ROUTES: BRANI SUONATI ────────────────────────────────────────────────────
@app.post("/api/tracks")
def log_track(data: TrackCreate, dj=Depends(get_current_dj)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO played_tracks
        (session_id, song_title, song_artist, song_year, song_album,
         duration_sec, source, request_id)
        VALUES (?,?,?,?,?,?,?,?)
    """, (data.session_id, data.song_title, data.song_artist,
          data.song_year, data.song_album, data.duration_sec,
          data.source, data.request_id))
    db.execute("UPDATE dj_sessions SET total_tracks=total_tracks+1 WHERE id=?",
               (data.session_id,))
    db.commit()
    db.close()
    return {"id": cur.lastrowid, "ok": True}

# ── ROUTES: RICHIESTE ────────────────────────────────────────────────────────
@app.get("/api/requests")
def get_requests(session_id: Optional[int] = None,
                  status: Optional[str] = None,
                  dj=Depends(get_current_dj)):
    db = get_db()
    q = "SELECT * FROM song_requests WHERE 1=1"
    params = []
    if session_id:
        q += " AND session_id=?"; params.append(session_id)
    if status:
        q += " AND status=?"; params.append(status)
    q += " ORDER BY requested_at DESC"
    rows = db.execute(q, params).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/requests")
def create_request(data: RequestCreate):
    """Crea richiesta — pubblica (dal sito/app)."""
    db = get_db()
    cur = db.execute("""
        INSERT INTO song_requests
        (session_id, requester_name, requester_contact, origin,
         song_title, song_artist, dedication)
        VALUES (?,?,?,?,?,?,?)
    """, (data.session_id, data.requester_name, data.requester_contact,
          data.origin, data.song_title, data.song_artist, data.dedication))
    db.commit()
    rid = cur.lastrowid
    db.close()
    return {"id": rid, "ok": True, "status": "pending"}

@app.put("/api/requests/{request_id}")
def update_request(request_id: int, data: RequestUpdate,
                   dj=Depends(get_current_dj)):
    db = get_db()
    played_at = datetime.utcnow() if data.status == "played" else None
    db.execute("""UPDATE song_requests
                  SET status=?, dj_note=?, played_at=?
                  WHERE id=?""",
               (data.status, data.dj_note, played_at, request_id))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: REGISTRAZIONI ────────────────────────────────────────────────────
@app.get("/api/recordings")
def get_recordings(published_only: bool = False):
    """Lista registrazioni — pubblica se published_only=True."""
    db = get_db()
    q = """SELECT r.*, s.program_name, s.date, d.display_name as dj_name
           FROM recordings r
           LEFT JOIN dj_sessions s ON r.session_id = s.id
           LEFT JOIN djs d ON s.dj_id = d.id
           WHERE 1=1"""
    params = []
    if published_only:
        q += " AND r.published=1"
    q += " ORDER BY r.created_at DESC"
    rows = db.execute(q, params).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.put("/api/recordings/{rec_id}/publish")
def publish_recording(rec_id: int, data: RecordingPublish,
                      dj=Depends(get_current_dj)):
    db = get_db()
    db.execute("""UPDATE recordings
                  SET published=1, published_title=?, published_desc=?,
                      published_at=?
                  WHERE id=?""",
               (data.published_title, data.published_desc,
                datetime.utcnow(), rec_id))
    db.commit()
    db.close()
    return {"ok": True}

@app.put("/api/recordings/{rec_id}/unpublish")
def unpublish_recording(rec_id: int, dj=Depends(get_current_dj)):
    db = get_db()
    db.execute("UPDATE recordings SET published=0 WHERE id=?", (rec_id,))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: ROADMAP ──────────────────────────────────────────────────────────
@app.get("/api/roadmap")
def get_roadmap(dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute("""SELECT * FROM roadmap
                         ORDER BY
                           CASE priority WHEN 'alta' THEN 1
                                         WHEN 'media' THEN 2
                                         ELSE 3 END,
                           created_at DESC""").fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/roadmap")
def create_roadmap_item(data: RoadmapCreate, dj=Depends(get_current_dj)):
    db = get_db()
    cur = db.execute("""INSERT INTO roadmap
                        (title, description, priority, status, target_version)
                        VALUES (?,?,?,?,?)""",
                     (data.title, data.description, data.priority,
                      data.status, data.target_version))
    db.commit()
    db.close()
    return {"id": cur.lastrowid, "ok": True}

@app.put("/api/roadmap/{item_id}")
def update_roadmap_item(item_id: int, data: dict, dj=Depends(get_current_dj)):
    db = get_db()
    completed_at = datetime.utcnow() if data.get("status") == "completata" else None
    db.execute("""UPDATE roadmap
                  SET status=?, priority=?, updated_at=?, completed_at=?
                  WHERE id=?""",
               (data.get("status"), data.get("priority"),
                datetime.utcnow(), completed_at, item_id))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: CHANGELOG ────────────────────────────────────────────────────────
@app.get("/api/changelog")
def get_changelog():
    """Pubblico — chiunque può vedere il changelog."""
    db = get_db()
    rows = db.execute("""SELECT * FROM changelog
                         ORDER BY date DESC, id DESC""").fetchall()
    db.close()
    return [dict(r) for r in rows]

# ── ROUTES: DJ MANAGEMENT ────────────────────────────────────────────────────
@app.get("/api/djs")
def get_djs(admin=Depends(require_admin)):
    db = get_db()
    rows = db.execute("""SELECT id, username, display_name, role,
                                active, created_at, last_login
                         FROM djs ORDER BY created_at""").fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/djs")
def create_dj(data: DJCreate, admin=Depends(require_admin)):
    db = get_db()
    existing = db.execute("SELECT id FROM djs WHERE username=?",
                          (data.username,)).fetchone()
    if existing:
        raise HTTPException(status_code=400, detail="Username già esistente")
    hashed = pwd_ctx.hash(data.password)
    cur = db.execute("""INSERT INTO djs (username, password_hash, display_name, role)
                        VALUES (?,?,?,?)""",
                     (data.username, hashed, data.display_name, data.role))
    db.commit()
    db.close()
    return {"id": cur.lastrowid, "ok": True}

@app.put("/api/djs/{dj_id}/toggle")
def toggle_dj(dj_id: int, admin=Depends(require_admin)):
    db = get_db()
    current = db.execute("SELECT active FROM djs WHERE id=?",
                         (dj_id,)).fetchone()
    if not current:
        raise HTTPException(status_code=404, detail="DJ non trovato")
    new_status = 0 if current["active"] else 1
    db.execute("UPDATE djs SET active=? WHERE id=?", (new_status, dj_id))
    db.commit()
    db.close()
    return {"ok": True, "active": bool(new_status)}

# ── ROUTES: STATISTICHE ──────────────────────────────────────────────────────
@app.get("/api/stats")
def get_stats(dj=Depends(get_current_dj)):
    db = get_db()
    stats = {
        "total_sessions":   db.execute("SELECT COUNT(*) FROM dj_sessions").fetchone()[0],
        "total_tracks":     db.execute("SELECT COUNT(*) FROM played_tracks").fetchone()[0],
        "total_requests":   db.execute("SELECT COUNT(*) FROM song_requests").fetchone()[0],
        "pending_requests": db.execute("SELECT COUNT(*) FROM song_requests WHERE status='pending'").fetchone()[0],
        "total_recordings": db.execute("SELECT COUNT(*) FROM recordings").fetchone()[0],
        "published_episodes": db.execute("SELECT COUNT(*) FROM recordings WHERE published=1").fetchone()[0],
        "current_session":  db.execute("SELECT id, program_name, status FROM dj_sessions WHERE status='on_air' LIMIT 1").fetchone(),
    }
    if stats["current_session"]:
        stats["current_session"] = dict(stats["current_session"])
    db.close()
    return stats

# ── ROUTES: BACKUP ───────────────────────────────────────────────────────────
@app.get("/api/backups")
def get_backups(dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute("SELECT * FROM backups ORDER BY created_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]

# ── AVVIO ────────────────────────────────────────────────────────────────────
@app.on_event("startup")
def startup():
    init_db()
    # Crea admin di default se non esiste
    db = get_db()
    admin = db.execute("SELECT id, password_hash FROM djs WHERE username='admin'").fetchone()
    if admin and admin["password_hash"] == "CHANGEME_HASH":
        default_hash = pwd_ctx.hash("RadioVinile2025!")
        db.execute("UPDATE djs SET password_hash=? WHERE username='admin'",
                   (default_hash,))
        db.commit()
        print("✅ Admin creato — password: RadioVinile2025! (CAMBIALA SUBITO)")
    db.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=False)
