/* ════════════════════════════════════════════════════
   RADIO VINILE — player.js
   Versione: v1.0 Rev 1.5
════════════════════════════════════════════════════ */

const Player = (() => {

  const STREAM_URL    = 'https://radiovinile.online/stream';
  const POLL_INTERVAL = 10000;

  let _audio   = null;
  let _playing = false;
  let _loading = false;

  function init() {
    _audio = document.getElementById('radio-audio');

    _audio.addEventListener('playing', () => {
      _loading = false; _playing = true;
      updatePlayBtn(); setVinylSpin(true); setStreamStatus(true);
    });
    _audio.addEventListener('pause', () => {
      _playing = false; updatePlayBtn(); setVinylSpin(false);
    });
    _audio.addEventListener('waiting', () => {
      _loading = true; updatePlayBtn();
    });
    _audio.addEventListener('error', () => {
      _loading = false; _playing = false;
      updatePlayBtn(); setStreamStatus(false);
    });

    document.getElementById('btn-play').addEventListener('click', togglePlay);
    document.getElementById('hero-play-btn').addEventListener('click', () => {
      play();
      document.getElementById('player').scrollIntoView({ behavior: 'smooth' });
    });

    const volBar  = document.querySelector('.vol-bar');
    const volFill = document.getElementById('vol-fill');
    if (volBar) {
      volBar.addEventListener('click', e => {
        const pct = Math.max(0, Math.min(1, e.offsetX / volBar.offsetWidth));
        _audio.volume = pct;
        volFill.style.width = (pct * 100) + '%';
      });
    }

    fetchNowPlaying();
    setInterval(fetchNowPlaying, POLL_INTERVAL);
  }

  function play() {
    if (_loading) return;
    if (!_audio.src || _audio.src === window.location.href) {
      _audio.src = STREAM_URL;
    }
    _loading = true;
    updatePlayBtn();
    _audio.play().catch(err => {
      _loading = false; _playing = false;
      updatePlayBtn();
      console.warn('Playback error:', err.message);
    });
  }

  function pause() {
    _audio.pause();
    _playing = false; _loading = false;
    updatePlayBtn(); setVinylSpin(false); setStreamStatus(false);
  }

  function togglePlay() { _playing ? pause() : play(); }

  function updatePlayBtn() {
    let icon = _loading ? '⏳' : (_playing ? '⏸' : '▶');
    const btn = document.getElementById('btn-play');
    if (btn) btn.textContent = icon;
    const hero = document.getElementById('hero-play-btn');
    if (hero) hero.textContent = _playing ? '⏸ In ascolto' : '▶ Ascolta ora';
    const dj = document.getElementById('dj-play-btn');
    if (dj) dj.textContent = _playing ? '⏸' : '▶';
  }

  function setVinylSpin(running) {
    const state = running ? 'running' : 'paused';
    ['hero-vinyl','player-disc','on-air-disc'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.animationPlayState = state;
    });
  }

  function setStreamStatus(online) {
    const el = document.getElementById('ver-stream-status');
    if (!el) return;
    el.textContent = online ? '🔴 In onda' : '⏸ Stream offline';
    el.style.color  = online ? 'var(--live)' : 'var(--t3)';
  }

  async function fetchNowPlaying() {
    try {
      const res  = await fetch('https://api.radiovinile.online/api/sessions/current');
      const data = await res.json();
      const title  = data.title  || 'Radio Vinile';
      const artist = data.artist || 'In onda';
      const count  = data.listeners !== undefined ? data.listeners : '—';
      const set = (id, v) => { const e = document.getElementById(id); if(e) e.textContent = v; };
      set('player-title',    title);
      set('player-artist',   artist);
      set('live-strip-song', artist + ' — ' + title);
      set('listener-count',  count);
      set('oa-title',        title);
      set('oa-artist',       artist);
    } catch(_) {}
  }

  function isPlaying() { return _playing; }
  return { init, play, pause, togglePlay, fetchNowPlaying, isPlaying };
})();
