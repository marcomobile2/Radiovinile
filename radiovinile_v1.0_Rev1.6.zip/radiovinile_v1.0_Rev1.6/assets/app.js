/* ════════════════════════════════════════════════════
   RADIO VINILE — app.js
   Orchestratore principale — init, routing viste,
   palinsesto, archivio
   Versione: v1.0 Rev 1.4
════════════════════════════════════════════════════ */

const App = (() => {

  // ── PALINSESTO DEMO ──
  const SCHEDULE = [
    { time: '08:00 — 12:00', name: 'Mattina con il Vinile', desc: 'Mix curato anni 70/80 per iniziare la giornata.', type: 'auto' },
    { time: '12:00 — 14:00', name: 'Pausa Anni 90', desc: 'Il meglio degli anni 90 all\'ora di pranzo.', type: 'auto' },
    { time: '19:00 — 22:00', name: 'Serata con Marco', desc: 'DJ Marco in diretta con vinili originali e chat aperta!', type: 'now' },
    { time: '22:00 — 01:00', name: 'Notte Soft Rock', desc: 'Le notti più belle con il soft rock anni 70.', type: 'live' },
  ];

  // ── ARCHIVIO DEMO ──
  const ARCHIVE = [
    { icon: '🕺', date: 'Ieri · 19:00', title: 'Discoteca Anni 80 — Speciale Italo', dj: 'DJ Marco · 2h 14m', prog: 0 },
    { icon: '🌙', date: '2 giorni fa · 22:00', title: 'Notte Soft Rock — Anni 70', dj: 'Automatica · 1h 58m', prog: 65 },
    { icon: '🎸', date: '5 giorni fa · 20:00', title: 'Rock Classics — Gli Immortali', dj: 'DJ Marco · 3h 02m', prog: 100 },
  ];

  function init() {
    hideLoader();
    initNav();
    initLogin();
    renderSchedule();
    renderArchive();

    // Inizializza moduli
    Player.init();
    Chat.init();

    // Se già loggato, vai al pannello DJ
    if (Auth.isLoggedIn()) {
      showDJ();
    } else {
      showPublic();
    }
  }

  // ── LOADER ──
  function hideLoader() {
    const loader = document.getElementById('app-loader');
    setTimeout(() => {
      loader.style.opacity = '0';
      loader.style.transition = 'opacity 0.5s ease';
      setTimeout(() => loader.style.display = 'none', 500);
    }, 800);
  }

  // ── NAVBAR ──
  function initNav() {
    document.getElementById('nav-ham').addEventListener('click', toggleMobileMenu);
    document.querySelectorAll('.mob-link').forEach(a => a.addEventListener('click', () => {
      document.getElementById('mob-menu').classList.add('hidden');
    }));

    // Scroll spy: attiva link navbar
    window.addEventListener('scroll', updateNavActive);
  }

  function toggleMobileMenu() {
    document.getElementById('mob-menu').classList.toggle('hidden');
  }

  function updateNavActive() {
    const sections = ['home', 'player', 'palinsesto', 'chat', 'archivio'];
    const scrollY = window.scrollY + 80;
    sections.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const link = document.querySelector(`.nav-links a[href="#${id}"]`);
      if (!link) return;
      const top = el.offsetTop;
      const bot = top + el.offsetHeight;
      link.style.color = (scrollY >= top && scrollY < bot) ? 'var(--a)' : '';
    });
  }

  // ── LOGIN ──
  function initLogin() {
    // Bottoni login
    document.getElementById('nav-login-btn').addEventListener('click', showLoginOverlay);
    document.getElementById('mob-login-btn').addEventListener('click', showLoginOverlay);

    // Submit login
    document.getElementById('login-submit').addEventListener('click', doLogin);
    document.getElementById('login-pass').addEventListener('keydown', e => {
      if (e.key === 'Enter') doLogin();
    });

    // Back
    document.getElementById('login-back-btn').addEventListener('click', e => {
      e.preventDefault();
      document.getElementById('login-overlay').classList.add('hidden');
    });
  }

  function showLoginOverlay() {
    document.getElementById('mob-menu').classList.add('hidden');
    document.getElementById('login-overlay').classList.remove('hidden');
    setTimeout(() => document.getElementById('login-user').focus(), 100);
  }

  async function doLogin() {
    const user  = document.getElementById('login-user').value.trim();
    const pass  = document.getElementById('login-pass').value;
    const errEl = document.getElementById('login-error');
    errEl.classList.add('hidden');

    if (!user || !pass) {
      errEl.textContent = 'Inserisci username e password';
      errEl.classList.remove('hidden');
      return;
    }

    const btn = document.getElementById('login-submit');
    btn.textContent = 'Accesso in corso...';
    btn.disabled = true;

    try {
      const dj = await Auth.login(user, pass);
      document.getElementById('login-overlay').classList.add('hidden');
      showDJ();
    } catch (e) {
      errEl.textContent = e.message || 'Credenziali non valide';
      errEl.classList.remove('hidden');
    } finally {
      btn.textContent = 'Accedi';
      btn.disabled = false;
    }
  }

  // ── VISTE ──
  function showPublic() {
    document.getElementById('view-public').style.display = 'block';
    document.getElementById('view-dj').classList.add('hidden');
    document.getElementById('main-nav').style.display = 'flex';
    document.getElementById('nav-login-btn').classList.remove('hidden');

    if (Auth.isLoggedIn()) {
      const dj = Auth.getDJ();
      const navDjBtn = document.getElementById('nav-dj-btn');
      navDjBtn.textContent = `🎙️ ${dj.display_name}`;
      navDjBtn.classList.remove('hidden');
      navDjBtn.addEventListener('click', showDJ);
      document.getElementById('nav-login-btn').classList.add('hidden');
    }
  }

  function showDJ() {
    if (!Auth.isLoggedIn()) {
      showLoginOverlay();
      return;
    }

    const dj = Auth.getDJ();
    document.getElementById('dj-welcome').textContent = dj.display_name;

    document.getElementById('view-public').style.display = 'none';
    document.getElementById('view-dj').classList.remove('hidden');
    document.getElementById('main-nav').style.display = 'none';
    document.getElementById('login-overlay').classList.add('hidden');

    // Init moduli DJ
    DJ.init();
    Admin.init();
  }

  // ── PALINSESTO ──
  function renderSchedule() {
    const grid = document.getElementById('sched-grid');
    if (!grid) return;
    grid.innerHTML = SCHEDULE.map(s => `
      <div class="sched-card${s.type === 'now' ? ' now' : ''}">
        <div class="sched-time">${s.time}</div>
        <div class="sched-name">${s.name}</div>
        <div class="sched-desc">${s.desc}</div>
        <span class="sched-badge ${s.type === 'auto' ? 'badge-auto' : s.type === 'live' ? 'badge-live' : 'badge-now'}">
          ${s.type === 'auto' ? 'Automatica' : s.type === 'live' ? 'Live' : '▶ Ora in onda'}
        </span>
      </div>
    `).join('');
  }

  // ── ARCHIVIO ──
  function renderArchive() {
    const grid = document.getElementById('archive-grid');
    if (!grid) return;
    grid.innerHTML = ARCHIVE.map(ep => `
      <div class="archive-card">
        <div class="archive-card-top">
          <div class="archive-cover">${ep.icon}</div>
          <div class="archive-info">
            <div class="archive-date">${ep.date}</div>
            <div class="archive-title">${ep.title}</div>
            <div class="archive-dj">${ep.dj}</div>
          </div>
        </div>
        <div class="archive-bar">
          <button class="archive-play-btn">▶</button>
          <div class="archive-prog-bg">
            <div class="stream-bar-fill amb" style="width:${ep.prog}%"></div>
          </div>
        </div>
      </div>
    `).join('');
  }

  return { init, showPublic, showDJ };

})();

// ── AVVIO ──
document.addEventListener('DOMContentLoaded', () => App.init());
