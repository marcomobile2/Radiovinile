#!/usr/bin/env python3
"""
================================================================================
RADIO VINILE — Backend API
File: api.py
Versione: v1.0 Rev 1.9
Novità: Google OAuth login ascoltatori, tabella listeners, endpoint /api/nowplaying
================================================================================
Dipendenze:
  pip install fastapi uvicorn python-jose passlib bcrypt python-multipart
              httpx google-auth google-auth-oauthlib --break-system-packages
"""

import sqlite3, os, hashlib, secrets, json, httpx
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends, status, UploadFile, File, Request
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import JWTError, jwt

# ── CONFIG ──────────────────────────────────────────────────────────────────
BASE_DIR   = Path("/opt/suimi/radiovinile")
DB_PATH    = BASE_DIR / "radiovinile.db"
REC_DIR    = BASE_DIR / "recordings"
BACKUP_DIR = BASE_DIR / "backups"
MUSIC_DIR  = BASE_DIR / "music"

SECRET_KEY         = os.environ.get("RV_SECRET", "radiovinile_secret_change_me_2026")
ALGORITHM          = "HS256"
TOKEN_EXPIRE_HOURS = 12
LISTENER_TOKEN_EXPIRE_DAYS = 30

# Google OAuth
GOOGLE_CLIENT_ID     = "354959497192-go6p7auqb5anrsbsupiu80h55i6vqmu0.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = "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"
GOOGLE_REDIRECT_URI  = "https://radiovinile.online/auth/google/callback"
GOOGLE_AUTH_URL      = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL     = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL  = "https://www.googleapis.com/oauth2/v2/userinfo"
FRONTEND_URL         = "https://radiovinile.online"
ICECAST_STATUS_URL   = "http://localhost:8950/status-json.xsl"

# Crea directory
for d in [REC_DIR / "sessions", REC_DIR / "calls", BACKUP_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── APP ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="Radio Vinile API", version="1.9.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_ctx  = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer(auto_error=False)

# ── DB ───────────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    # Tabella listeners (ascoltatori)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS listeners (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            google_id    TEXT UNIQUE,
            email        TEXT UNIQUE NOT NULL,
            display_name TEXT NOT NULL,
            avatar_url   TEXT,
            provider     TEXT DEFAULT 'google',
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login   DATETIME DEFAULT CURRENT_TIMESTAMP,
            login_count  INTEGER DEFAULT 1,
            is_active    INTEGER DEFAULT 1
        )
    """)
    # Tabella preferiti ascoltatori
    conn.execute("""
        CREATE TABLE IF NOT EXISTS listener_favorites (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            listener_id INTEGER NOT NULL,
            song_title  TEXT NOT NULL,
            song_artist TEXT,
            song_year   TEXT,
            saved_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (listener_id) REFERENCES listeners(id),
            UNIQUE(listener_id, song_title, song_artist)
        )
    """)
    # Tabella playlist ascoltatori
    conn.execute("""
        CREATE TABLE IF NOT EXISTS listener_playlists (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            listener_id INTEGER NOT NULL,
            name        TEXT NOT NULL,
            description TEXT,
            emoji       TEXT DEFAULT '🎵',
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (listener_id) REFERENCES listeners(id)
        )
    """)
    # Tabella tracce playlist
    conn.execute("""
        CREATE TABLE IF NOT EXISTS playlist_tracks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL,
            song_title  TEXT NOT NULL,
            song_artist TEXT,
            song_year   TEXT,
            added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (playlist_id) REFERENCES listener_playlists(id)
        )
    """)
    # Tabella invii redazione
    conn.execute("""
        CREATE TABLE IF NOT EXISTS listener_submissions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            listener_id INTEGER,
            title       TEXT NOT NULL,
            message     TEXT,
            type        TEXT DEFAULT 'recording',
            song_ref    TEXT,
            is_public   INTEGER DEFAULT 0,
            file_path   TEXT,
            status      TEXT DEFAULT 'pending',
            admin_note  TEXT,
            submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            reviewed_at  DATETIME,
            FOREIGN KEY (listener_id) REFERENCES listeners(id)
        )
    """)
    conn.commit()
    conn.close()

# Inizializza DB all'avvio
try:
    init_db()
except Exception as e:
    print(f"DB init warning: {e}")

# ── AUTH DJ ──────────────────────────────────────────────────────────────────
def create_dj_token(data: dict) -> str:
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS)
    payload["type"] = "dj"
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def create_listener_token(data: dict) -> str:
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(days=LISTENER_TOKEN_EXPIRE_DAYS)
    payload["type"] = "listener"
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Token mancante")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Token non valido")

def get_current_dj(token_data: dict = Depends(verify_token)):
    if token_data.get("type") != "dj":
        raise HTTPException(status_code=401, detail="Token DJ richiesto")
    db = get_db()
    dj = db.execute("SELECT * FROM djs WHERE id=? AND active=1",
                    (token_data.get("dj_id"),)).fetchone()
    db.close()
    if not dj:
        raise HTTPException(status_code=401, detail="DJ non trovato")
    return dict(dj)

def require_admin(dj=Depends(get_current_dj)):
    if dj["role"] != "admin":
        raise HTTPException(status_code=403, detail="Solo admin")
    return dj

def get_current_listener(token_data: dict = Depends(verify_token)):
    if token_data.get("type") != "listener":
        raise HTTPException(status_code=401, detail="Token listener richiesto")
    db = get_db()
    listener = db.execute("SELECT * FROM listeners WHERE id=? AND is_active=1",
                          (token_data.get("listener_id"),)).fetchone()
    db.close()
    if not listener:
        raise HTTPException(status_code=401, detail="Ascoltatore non trovato")
    return dict(listener)

# ── MODELLI ──────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class SessionCreate(BaseModel):
    program_name: str
    program_desc: Optional[str] = None
    date: str
    time_start: Optional[str] = None
    is_live: bool = True

class TrackCreate(BaseModel):
    session_id: int
    song_title: str
    song_artist: str
    song_year: Optional[int] = None
    source: str = "digital"
    request_id: Optional[int] = None

class RequestCreate(BaseModel):
    session_id: Optional[int] = None
    requester_name: str
    origin: str = "web"
    song_title: str
    song_artist: Optional[str] = None
    dedication: Optional[str] = None

class FavoriteCreate(BaseModel):
    song_title: str
    song_artist: Optional[str] = None
    song_year: Optional[str] = None

class PlaylistCreate(BaseModel):
    name: str
    description: Optional[str] = None
    emoji: str = "🎵"

class PlaylistTrackAdd(BaseModel):
    song_title: str
    song_artist: Optional[str] = None
    song_year: Optional[str] = None

class SubmissionCreate(BaseModel):
    title: str
    message: Optional[str] = None
    type: str = "recording"
    song_ref: Optional[str] = None
    is_public: bool = False

class OnDemandSearch(BaseModel):
    q: str

class OnDemandPlay(BaseModel):
    video_id: str
    title: str

class PlaylistImport(BaseModel):
    url: str
    type: str  # youtube | spotify

# ── ROUTES: STATUS ───────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"status": "online", "service": "Radio Vinile API", "version": "1.9.0"}

@app.get("/api/nowplaying")
async def now_playing():
    """Proxy Icecast → restituisce brano corrente. Risolve CORS su Safari/iOS."""
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            res = await client.get(ICECAST_STATUS_URL)
            data = res.json()
            src = data.get("icestats", {}).get("source")
            if not src:
                return {"title": "In onda...", "artist": "", "year": "", "listeners": 0}
            raw    = src.get("title", "") or ""
            parts  = raw.split(" - ")
            if len(parts) >= 3 and len(parts[0].strip()) == 4 and parts[0].strip().isdigit():
                year   = parts[0].strip()
                artist = parts[1].strip()
                title  = " - ".join(parts[2:]).strip()
            elif len(parts) >= 2:
                year   = ""
                artist = parts[0].strip()
                title  = " - ".join(parts[1:]).strip()
            else:
                year, artist, title = "", "Radio Vinile", raw or "In onda..."
            return {
                "title":     title,
                "artist":    artist,
                "year":      year,
                "listeners": src.get("listeners", 0),
                "raw":       raw
            }
    except Exception:
        return {"title": "In onda...", "artist": "", "year": "", "listeners": 0}

# ── ROUTES: AUTH DJ ───────────────────────────────────────────────────────────
@app.post("/api/auth/login")
def login(req: LoginRequest):
    db = get_db()
    dj = db.execute("SELECT * FROM djs WHERE username=? AND active=1",
                    (req.username,)).fetchone()
    db.close()
    if not dj or not pwd_ctx.verify(req.password, dj["password_hash"]):
        raise HTTPException(status_code=401, detail="Credenziali non valide")
    token = create_dj_token({"dj_id": dj["id"], "role": dj["role"]})
    return {
        "token":        token,
        "dj_id":        dj["id"],
        "display_name": dj["display_name"],
        "role":         dj["role"]
    }

# ── ROUTES: GOOGLE OAUTH ──────────────────────────────────────────────────────
@app.get("/auth/google/login")
def google_login():
    """Reindirizza a Google per il consenso OAuth."""
    state = secrets.token_urlsafe(16)
    params = {
        "client_id":     GOOGLE_CLIENT_ID,
        "redirect_uri":  GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope":         "openid email profile",
        "state":         state,
        "access_type":   "offline",
        "prompt":        "select_account"
    }
    url = GOOGLE_AUTH_URL + "?" + "&".join(f"{k}={v}" for k, v in params.items())
    return RedirectResponse(url)

@app.get("/auth/google/callback")
async def google_callback(code: str, state: str = ""):
    """Callback OAuth Google — scambia codice per token e salva utente nel DB."""
    try:
        async with httpx.AsyncClient() as client:
            # Scambia code per access_token
            token_res = await client.post(GOOGLE_TOKEN_URL, data={
                "code":          code,
                "client_id":     GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "redirect_uri":  GOOGLE_REDIRECT_URI,
                "grant_type":    "authorization_code"
            })
            token_data = token_res.json()
            access_token = token_data.get("access_token")
            if not access_token:
                raise HTTPException(status_code=400, detail="Token Google non ricevuto")

            # Legge profilo utente
            user_res = await client.get(
                GOOGLE_USERINFO_URL,
                headers={"Authorization": f"Bearer {access_token}"}
            )
            user_info = user_res.json()

        google_id    = user_info.get("id")
        email        = user_info.get("email")
        display_name = user_info.get("name", email)
        avatar_url   = user_info.get("picture", "")
        now          = datetime.now().isoformat()

        if not email:
            raise HTTPException(status_code=400, detail="Email non ricevuta da Google")

        # Salva o aggiorna nel DB
        db = get_db()
        existing = db.execute(
            "SELECT * FROM listeners WHERE google_id=? OR email=?",
            (google_id, email)
        ).fetchone()

        if existing:
            # Aggiorna ultimo login
            db.execute("""
                UPDATE listeners
                SET last_login=?, login_count=login_count+1,
                    avatar_url=?, display_name=?, google_id=?
                WHERE id=?
            """, (now, avatar_url, display_name, google_id, existing["id"]))
            listener_id = existing["id"]
        else:
            # Nuovo utente
            cur = db.execute("""
                INSERT INTO listeners (google_id, email, display_name, avatar_url, provider, created_at, last_login)
                VALUES (?, ?, ?, ?, 'google', ?, ?)
            """, (google_id, email, display_name, avatar_url, now, now))
            listener_id = cur.lastrowid

        db.commit()
        db.close()

        # Crea token JWT listener
        rv_token = create_listener_token({
            "listener_id":  listener_id,
            "email":        email,
            "display_name": display_name,
            "avatar_url":   avatar_url,
            "provider":     "google"
        })

        # Reindirizza al frontend con token nell'URL hash
        redirect_url = f"{FRONTEND_URL}?rv_token={rv_token}&login=success"
        return RedirectResponse(redirect_url)

    except HTTPException:
        raise
    except Exception as e:
        return RedirectResponse(f"{FRONTEND_URL}?login=error&msg={str(e)}")

@app.get("/api/auth/me")
def get_me(listener=Depends(get_current_listener)):
    """Restituisce il profilo dell'ascoltatore loggato."""
    return {
        "id":           listener["id"],
        "email":        listener["email"],
        "display_name": listener["display_name"],
        "avatar_url":   listener["avatar_url"],
        "provider":     listener["provider"],
        "created_at":   listener["created_at"],
        "last_login":   listener["last_login"],
        "login_count":  listener["login_count"]
    }

# ── ROUTES: PREFERITI ─────────────────────────────────────────────────────────
@app.get("/api/favorites")
def get_favorites(listener=Depends(get_current_listener)):
    db = get_db()
    favs = db.execute(
        "SELECT * FROM listener_favorites WHERE listener_id=? ORDER BY saved_at DESC",
        (listener["id"],)
    ).fetchall()
    db.close()
    return [dict(f) for f in favs]

@app.post("/api/favorites")
def add_favorite(fav: FavoriteCreate, listener=Depends(get_current_listener)):
    db = get_db()
    try:
        db.execute("""
            INSERT OR IGNORE INTO listener_favorites (listener_id, song_title, song_artist, song_year)
            VALUES (?, ?, ?, ?)
        """, (listener["id"], fav.song_title, fav.song_artist, fav.song_year))
        db.commit()
    except Exception as e:
        db.close()
        raise HTTPException(status_code=400, detail=str(e))
    db.close()
    return {"ok": True}

@app.delete("/api/favorites/{fav_id}")
def remove_favorite(fav_id: int, listener=Depends(get_current_listener)):
    db = get_db()
    db.execute("DELETE FROM listener_favorites WHERE id=? AND listener_id=?",
               (fav_id, listener["id"]))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: PLAYLIST ──────────────────────────────────────────────────────────
@app.get("/api/playlists")
def get_playlists(listener=Depends(get_current_listener)):
    db = get_db()
    pls = db.execute(
        "SELECT * FROM listener_playlists WHERE listener_id=? ORDER BY created_at DESC",
        (listener["id"],)
    ).fetchall()
    result = []
    for pl in pls:
        tracks = db.execute(
            "SELECT * FROM playlist_tracks WHERE playlist_id=? ORDER BY added_at",
            (pl["id"],)
        ).fetchall()
        d = dict(pl)
        d["tracks"] = [dict(t) for t in tracks]
        result.append(d)
    db.close()
    return result

@app.post("/api/playlists")
def create_playlist(pl: PlaylistCreate, listener=Depends(get_current_listener)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO listener_playlists (listener_id, name, description, emoji)
        VALUES (?, ?, ?, ?)
    """, (listener["id"], pl.name, pl.description, pl.emoji))
    db.commit()
    pl_id = cur.lastrowid
    db.close()
    return {"ok": True, "id": pl_id}

@app.post("/api/playlists/{pl_id}/tracks")
def add_track_to_playlist(pl_id: int, track: PlaylistTrackAdd, listener=Depends(get_current_listener)):
    db = get_db()
    pl = db.execute("SELECT * FROM listener_playlists WHERE id=? AND listener_id=?",
                    (pl_id, listener["id"])).fetchone()
    if not pl:
        db.close()
        raise HTTPException(status_code=404, detail="Playlist non trovata")
    db.execute("""
        INSERT INTO playlist_tracks (playlist_id, song_title, song_artist, song_year)
        VALUES (?, ?, ?, ?)
    """, (pl_id, track.song_title, track.song_artist, track.song_year))
    db.commit()
    db.close()
    return {"ok": True}

@app.delete("/api/playlists/{pl_id}")
def delete_playlist(pl_id: int, listener=Depends(get_current_listener)):
    db = get_db()
    db.execute("DELETE FROM playlist_tracks WHERE playlist_id=?", (pl_id,))
    db.execute("DELETE FROM listener_playlists WHERE id=? AND listener_id=?",
               (pl_id, listener["id"]))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: INVII REDAZIONE ───────────────────────────────────────────────────
@app.get("/api/submissions")
def get_submissions(listener=Depends(get_current_listener)):
    db = get_db()
    subs = db.execute(
        "SELECT * FROM listener_submissions WHERE listener_id=? ORDER BY submitted_at DESC",
        (listener["id"],)
    ).fetchall()
    db.close()
    return [dict(s) for s in subs]

@app.post("/api/submissions")
def create_submission(sub: SubmissionCreate, listener=Depends(get_current_listener)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO listener_submissions (listener_id, title, message, type, song_ref, is_public)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (listener["id"], sub.title, sub.message, sub.type, sub.song_ref, int(sub.is_public)))
    db.commit()
    sub_id = cur.lastrowid
    db.close()
    return {"ok": True, "id": sub_id}

@app.get("/api/admin/submissions")
def get_all_submissions(dj=Depends(require_admin)):
    """Lista tutti gli invii in attesa — solo admin."""
    db = get_db()
    subs = db.execute("""
        SELECT s.*, l.display_name as listener_name, l.email as listener_email
        FROM listener_submissions s
        LEFT JOIN listeners l ON s.listener_id = l.id
        ORDER BY s.submitted_at DESC
    """).fetchall()
    db.close()
    return [dict(s) for s in subs]

@app.put("/api/admin/submissions/{sub_id}")
def review_submission(sub_id: int, data: dict, dj=Depends(require_admin)):
    """Approva o rifiuta un invio — solo admin."""
    db = get_db()
    db.execute("""
        UPDATE listener_submissions
        SET status=?, admin_note=?, reviewed_at=?
        WHERE id=?
    """, (data.get("status"), data.get("note"), datetime.now().isoformat(), sub_id))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: SESSIONI DJ ───────────────────────────────────────────────────────
@app.get("/api/sessions/current")
def get_current_session():
    """Brano in onda — usa il proxy Icecast."""
    import asyncio
    try:
        import subprocess
        res = subprocess.run(
            ["curl", "-s", "--max-time", "2", ICECAST_STATUS_URL],
            capture_output=True, text=True, timeout=3
        )
        data = json.loads(res.stdout)
        src  = data.get("icestats", {}).get("source")
        if src:
            raw   = src.get("title", "") or ""
            parts = raw.split(" - ")
            if len(parts) >= 3 and parts[0].strip().isdigit() and len(parts[0].strip()) == 4:
                year, artist, title = parts[0].strip(), parts[1].strip(), " - ".join(parts[2:]).strip()
            elif len(parts) >= 2:
                year, artist, title = "", parts[0].strip(), " - ".join(parts[1:]).strip()
            else:
                year, artist, title = "", "Radio Vinile", raw or "In onda..."
            return {"title": title, "artist": artist, "year": year, "listeners": src.get("listeners", 0)}
    except Exception:
        pass
    return {"title": "In onda...", "artist": "", "year": "", "listeners": 0}

@app.get("/api/sessions")
def get_sessions(limit: int = 20, dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute("""
        SELECT s.*, d.display_name as dj_name
        FROM dj_sessions s LEFT JOIN djs d ON s.dj_id = d.id
        ORDER BY s.time_start DESC LIMIT ?
    """, (limit,)).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/sessions")
def create_session(data: SessionCreate, dj=Depends(get_current_dj)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO dj_sessions (dj_id, program_name, program_desc, date, time_start, is_live, status)
        VALUES (?, ?, ?, ?, ?, ?, 'scheduled')
    """, (dj["id"], data.program_name, data.program_desc, data.date, data.time_start, int(data.is_live)))
    db.commit()
    session_id = cur.lastrowid
    db.close()
    return {"ok": True, "session_id": session_id}

@app.put("/api/sessions/{session_id}/start")
def start_session(session_id: int, dj=Depends(get_current_dj)):
    db = get_db()
    db.execute("UPDATE dj_sessions SET status='on_air', time_start=? WHERE id=?",
               (datetime.now().isoformat(), session_id))
    db.commit()
    db.close()
    return {"ok": True}

@app.put("/api/sessions/{session_id}/end")
def end_session(session_id: int, dj=Depends(get_current_dj)):
    db = get_db()
    db.execute("UPDATE dj_sessions SET status='ended', time_end=? WHERE id=?",
               (datetime.now().isoformat(), session_id))
    db.commit()
    db.close()
    return {"ok": True}

# ── ROUTES: BRANI ─────────────────────────────────────────────────────────────
@app.post("/api/tracks")
def log_track(data: TrackCreate, dj=Depends(get_current_dj)):
    db = get_db()
    cur = db.execute("""
        INSERT INTO played_tracks (session_id, song_title, song_artist, song_year, source, request_id, played_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (data.session_id, data.song_title, data.song_artist, data.song_year,
          data.source, data.request_id, datetime.now().isoformat()))
    db.commit()
    db.close()
    return {"ok": True, "track_id": cur.lastrowid}

# ── ROUTES: RICHIESTE ─────────────────────────────────────────────────────────
@app.get("/api/requests")
def get_requests(status: str = "pending", dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute(
        "SELECT * FROM song_requests WHERE status=? ORDER BY requested_at DESC",
        (status,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.post("/api/requests")
def create_request(data: RequestCreate):
    db = get_db()
    cur = db.execute("""
        INSERT INTO song_requests (session_id, requester_name, origin, song_title, song_artist, dedication, requested_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (data.session_id, data.requester_name, data.origin,
          data.song_title, data.song_artist, data.dedication, datetime.now().isoformat()))
    db.commit()
    db.close()
    return {"ok": True, "request_id": cur.lastrowid}

@app.post("/api/requests/{req_id}/play")
def play_request(req_id: int, data: dict, dj=Depends(get_current_dj)):
    """Accetta richiesta e avvia download on-demand via yt-dlp."""
    import subprocess
    song_title  = data.get("song_title", "")
    song_artist = data.get("song_artist", "")
    query = f"{song_artist} {song_title}".strip()
    output_dir = str(BASE_DIR / "music" / "all")
    os.makedirs(output_dir, exist_ok=True)
    try:
        subprocess.Popen([
            "yt-dlp", "-x", "--audio-format", "mp3", "--audio-quality", "192K",
            "-o", f"{output_dir}/%(artist)s - %(title)s.%(ext)s",
            "--ignore-errors", "--no-playlist",
            f"ytsearch1:{query}"
        ])
        db = get_db()
        db.execute("UPDATE song_requests SET status='accepted' WHERE id=?", (req_id,))
        db.commit()
        db.close()
        return {"ok": True, "msg": f"Download avviato per: {query}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ── ROUTES: ON-DEMAND ─────────────────────────────────────────────────────────
@app.get("/api/ondemand/search")
def ondemand_search(q: str, dj=Depends(get_current_dj)):
    """Cerca brano su YouTube via yt-dlp."""
    import subprocess, json as _json
    try:
        res = subprocess.run([
            "yt-dlp", "--dump-json", "--no-playlist", "--max-downloads", "5",
            f"ytsearch5:{q}"
        ], capture_output=True, text=True, timeout=15)
        results = []
        for line in res.stdout.strip().split("\n"):
            if not line: continue
            try:
                v = _json.loads(line)
                results.append({
                    "id":       v.get("id"),
                    "title":    v.get("title"),
                    "artist":   v.get("uploader", ""),
                    "duration": str(int(v.get("duration", 0) // 60)) + ":" + str(int(v.get("duration", 0) % 60)).zfill(2),
                    "thumb":    "🎵"
                })
            except Exception:
                continue
        return {"results": results}
    except Exception as e:
        return {"results": [], "error": str(e)}

@app.post("/api/ondemand/play")
def ondemand_play(data: OnDemandPlay, dj=Depends(get_current_dj)):
    """Scarica MP3 da YouTube e lo accoda su Liquidsoap via telnet."""
    import subprocess
    video_id   = data.video_id
    output_dir = str(BASE_DIR / "music" / "all")
    os.makedirs(output_dir, exist_ok=True)
    try:
        subprocess.Popen([
            "yt-dlp", "-x", "--audio-format", "mp3", "--audio-quality", "192K",
            "-o", f"{output_dir}/%(artist)s - %(title)s.%(ext)s",
            "--ignore-errors",
            f"https://www.youtube.com/watch?v={video_id}"
        ])
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ── ROUTES: CHANGELOG & ROADMAP ───────────────────────────────────────────────
@app.get("/api/changelog")
def get_changelog():
    db = get_db()
    rows = db.execute("SELECT * FROM changelog ORDER BY created_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/roadmap")
def get_roadmap(dj=Depends(get_current_dj)):
    db = get_db()
    rows = db.execute("SELECT * FROM roadmap ORDER BY created_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]

@app.get("/api/stats")
def get_stats(dj=Depends(get_current_dj)):
    db = get_db()
    listeners_count = db.execute("SELECT COUNT(*) as n FROM listeners").fetchone()["n"]
    favs_count      = db.execute("SELECT COUNT(*) as n FROM listener_favorites").fetchone()["n"]
    sessions_count  = db.execute("SELECT COUNT(*) as n FROM dj_sessions").fetchone()["n"]
    tracks_count    = db.execute("SELECT COUNT(*) as n FROM played_tracks").fetchone()["n"]
    db.close()
    return {
        "listeners": listeners_count,
        "favorites": favs_count,
        "sessions":  sessions_count,
        "tracks":    tracks_count
    }

@app.get("/api/djs")
def get_djs(dj=Depends(require_admin)):
    db = get_db()
    rows = db.execute("SELECT id, username, display_name, role, active FROM djs").fetchall()
    db.close()
    return [dict(r) for r in rows]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=False)

# ── ROUTE: INFO BRANO CON GOSSIP (Claude AI) ─────────────────────────────────
import httpx as _httpx

class TrackInfoRequest(BaseModel):
    title:  str
    artist: str
    year:   Optional[str] = ""

@app.post("/api/track/info")
async def get_track_info(req: TrackInfoRequest, dj=Depends(get_current_dj)):
    """Restituisce curiosità e gossip sul brano usando Claude AI + MusicBrainz."""
    import asyncio as _asyncio

    # ── Claude AI ──
    async def get_gossip():
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return {"gossip": "🔥 Configura ANTHROPIC_API_KEY per il gossip!", "curiosity": "🎵 API key mancante.", "chart": ""}
        prompt = f"""Sei un esperto di musica rock, pop e disco degli anni 70, 80 e 90.
Rispondimi con un JSON con questi campi:
- "gossip": retroscena piccante/scandalo/storia sorprendente su questo brano o artista. Max 3 righe. Inizia con emoji (🔥💋😱🎸💀).
- "curiosity": curiosità storica interessante. Max 2 righe. Inizia con 🎵
- "chart": posizione più alta in classifica (Billboard/UK/Italia). Max 1 riga.

Brano: "{req.title}" di {req.artist}{f' ({req.year})' if req.year else ''}
Rispondi SOLO con il JSON."""
        try:
            async with _httpx.AsyncClient(timeout=12.0) as c:
                r = await c.post("https://api.anthropic.com/v1/messages",
                    headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                    json={"model": "claude-haiku-4-5-20251001", "max_tokens": 350,
                          "messages": [{"role": "user", "content": prompt}]})
                text = r.json()["content"][0]["text"].strip().replace("```json","").replace("```","").strip()
                return json.loads(text)
        except Exception as e:
            return {"gossip": f"🔥 Errore: {str(e)}", "curiosity": "🎵 Errore nel recupero.", "chart": ""}

    # ── MusicBrainz ──
    async def get_mb():
        try:
            async with _httpx.AsyncClient(timeout=6.0) as c:
                r = await c.get(f"{MUSICBRAINZ_URL}/recording",
                    params={"query": f'recording:"{req.title}" AND artist:"{req.artist}"', "limit": 1, "fmt": "json"},
                    headers={"User-Agent": "RadioVinile/2.0 (radiovinile.online)"})
                recs = r.json().get("recordings", [])
                if not recs: return {}
                rec = recs[0]
                for rel in rec.get("releases", []):
                    d = rel.get("date", "")
                    if d and len(d) >= 4:
                        return {"mb_year": d[:4], "mb_album": rel.get("title",""), "mb_length": rec.get("length",0)}
        except Exception:
            pass
        return {}

    gossip_data, mb_data = await _asyncio.gather(get_gossip(), get_mb())

    return {
        "title":      req.title,
        "artist":     req.artist,
        "year":       mb_data.get("mb_year") or req.year or "",
        "album":      mb_data.get("mb_album", ""),
        "duration":   f"{mb_data.get('mb_length',0)//60000}:{str((mb_data.get('mb_length',0)%60000)//1000).zfill(2)}" if mb_data.get("mb_length") else "",
        "gossip":     gossip_data.get("gossip", ""),
        "curiosity":  gossip_data.get("curiosity", ""),
        "chart":      gossip_data.get("chart", ""),
    }
