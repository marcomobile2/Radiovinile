/* ════════════════════════════════════════════════════
   RADIO VINILE — dj.js
   Pannello DJ: coda, richieste, mic, telefonate,
   on-demand, import playlist YouTube/Spotify
   Versione: v1.0 Rev 1.6
════════════════════════════════════════════════════ */

const DJ = (() => {

  let _isLive  = true;
  let _micHot  = true;
  let _sessionId = null;

  // ── DEMO DATA ──
  const DEMO_QUEUE = [
    { title: 'Africa', artist: 'Toto', year: 1982, playing: true },
    { title: 'Take On Me', artist: 'a-ha', year: 1985 },
    { title: 'Rio', artist: 'Duran Duran', year: 1982 },
    { title: "Don't You Want Me", artist: 'Human League', year: 1981 },
    { title: 'Total Eclipse of the Heart', artist: 'Bonnie Tyler', year: 1983 },
  ];

  const DEMO_REQUESTS = [
    { id: 1, song: 'Rio', artist: 'Duran Duran', year: 1982, requester: 'Giovanni_B', origin: 'web', msg: 'Lo dedico a mia moglie 💕', time: '19:07' },
    { id: 2, song: 'Total Eclipse of the Heart', artist: 'Bonnie Tyler', year: 1983, requester: 'Lucia_F', origin: 'chat', msg: 'È il mio compleanno!', time: '19:05' },
    { id: 3, song: "Don't You Want Me", artist: 'Human League', year: 1981, requester: 'Andrea_V', origin: 'whatsapp', msg: '', time: '19:01' },
  ];

  const DEMO_CALLS = [
    { id: 1, number: '+39 333 456 7890', status: 'wait', duration: '0:42' },
    { id: 2, number: '+39 347 891 2345', status: 'live', duration: '1:23' },
  ];

  function init() {
    renderQueue();
    renderRequests();
    renderCalls();
    initTabs();
    initControls();
    initOnDemand();
    initPlaylistImport();
    updateStats();
  }

  // ── CODA ──
  function renderQueue() {
    const list = document.getElementById('queue-list');
    if (!list) return;
    list.innerHTML = DEMO_QUEUE.map((t, i) => `
      <div class="queue-item${t.playing ? ' playing' : ''}">
        <div class="q-num">${t.playing ? '▶' : i + 1}</div>
        <div class="q-disc">🎵</div>
        <div class="q-info">
          <div class="q-title">${t.title}</div>
          <div class="q-artist">${t.artist}</div>
        </div>
        <div class="q-year">${t.year}</div>
      </div>
    `).join('');
  }

  // ── RICHIESTE ──
  function renderRequests() {
    const list = document.getElementById('req-list');
    if (!list) return;
    list.innerHTML = DEMO_REQUESTS.map(r => `
      <div class="req-card" id="req-${r.id}">
        <div class="req-top">
          <div>
            <div class="req-song">${r.song}</div>
            <div class="req-artist">${r.artist}${r.year ? ' · ' + r.year : ''}</div>
          </div>
          <div class="req-time">${r.time}</div>
        </div>
        ${r.msg ? `<div class="req-msg">"${r.msg}"</div>` : ''}
        <div class="req-footer">
          <div class="req-by">${r.requester} <span class="req-origin">${r.origin}</span></div>
          <div class="req-actions">
            <button class="req-btn req-btn-acc" onclick="DJ.acceptRequest(${r.id}, '${r.song}', '${r.artist}', this)">▶ Metti in onda</button>
            <button class="req-btn req-btn-skip" onclick="DJ.skipRequest(${r.id}, this)">Salta</button>
          </div>
        </div>
      </div>
    `).join('');
    updateReqBadge();
  }

  function acceptRequest(id, song, artist, btn) {
    const card = document.getElementById('req-' + id);
    card.classList.add('accepted');

    // Feedback visivo immediato
    btn.textContent = '⏳ Cercando...';
    btn.disabled = true;

    // Chiama API per scaricare e accodare il brano
    Auth.authFetch('/requests/' + id + '/play', {
      method: 'POST',
      body: JSON.stringify({ song_title: song, song_artist: artist })
    }).then(async res => {
      const data = await res.json();
      if (data.ok) {
        btn.textContent = '✅ In coda!';
        Chat.addActivity('🎵', `"${song}" di ${artist} aggiunto in coda`, 'icon-req');
      } else {
        btn.textContent = '⚠️ Errore';
      }
    }).catch(() => {
      // Demo mode — simula successo
      btn.textContent = '✅ In coda!';
      Chat.addActivity('🎵', `"${song}" di ${artist} aggiunto in coda`, 'icon-req');
    });

    const pending = document.querySelectorAll('.req-card:not(.accepted)').length - 1;
    document.getElementById('req-badge').textContent = Math.max(0, pending);
    document.getElementById('stat-req').textContent = Math.max(0, pending);
  }

  function skipRequest(id, btn) {
    const card = document.getElementById('req-' + id);
    card.style.opacity = '0.4';
    btn.textContent = 'Saltata';
    btn.disabled = true;
    card.querySelector('.req-btn-acc').disabled = true;
  }

  function updateReqBadge() {
    const count = DEMO_REQUESTS.length;
    document.getElementById('req-badge').textContent = count;
    document.getElementById('stat-req').textContent = count;
  }

  // ── ON-DEMAND ──
  function initOnDemand() {
    const searchBtn = document.getElementById('ondemand-search');
    const input     = document.getElementById('ondemand-input');
    if (!searchBtn || !input) return;

    searchBtn.addEventListener('click', searchOnDemand);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') searchOnDemand(); });
  }

  async function searchOnDemand() {
    const input  = document.getElementById('ondemand-input');
    const results = document.getElementById('ondemand-results');
    const query  = input.value.trim();
    if (!query) return;

    results.innerHTML = '<div class="od-searching">⏳ Cercando su YouTube...</div>';

    try {
      const res  = await Auth.authFetch('/ondemand/search?q=' + encodeURIComponent(query));
      const data = await res.json();
      renderOnDemandResults(data.results || []);
    } catch (_) {
      // Demo mode
      renderOnDemandResults([
        { id: 'demo1', title: query + ' (risultato demo)', artist: 'Artista', duration: '3:45', thumb: '🎵' },
        { id: 'demo2', title: query + ' - Live Version', artist: 'Artista Live', duration: '4:12', thumb: '🎵' },
      ]);
    }
  }

  function renderOnDemandResults(results) {
    const container = document.getElementById('ondemand-results');
    if (!results.length) {
      container.innerHTML = '<div class="od-empty">Nessun risultato trovato</div>';
      return;
    }
    container.innerHTML = results.map(r => `
      <div class="od-result">
        <div class="od-thumb">${r.thumb || '🎵'}</div>
        <div class="od-info">
          <div class="od-title">${r.title}</div>
          <div class="od-artist">${r.artist} · ${r.duration}</div>
        </div>
        <button class="od-play-btn" onclick="DJ.playOnDemand('${r.id}', '${r.title.replace(/'/g,'\\'')}', this)">
          ▶ In onda
        </button>
      </div>
    `).join('');
  }

  async function playOnDemand(videoId, title, btn) {
    btn.textContent = '⏳';
    btn.disabled = true;

    try {
      const res  = await Auth.authFetch('/ondemand/play', {
        method: 'POST',
        body: JSON.stringify({ video_id: videoId, title })
      });
      const data = await res.json();
      btn.textContent = '✅';
      Chat.addActivity('🎵', `On-demand: "${title}" aggiunto in coda`, 'icon-req');
    } catch (_) {
      btn.textContent = '✅';
      Chat.addActivity('🎵', `On-demand: "${title}" aggiunto in coda`, 'icon-req');
    }
  }

  // ── IMPORT PLAYLIST ──
  function initPlaylistImport() {
    const importBtn = document.getElementById('playlist-import-btn');
    if (!importBtn) return;
    importBtn.addEventListener('click', importPlaylist);
  }

  async function importPlaylist() {
    const input  = document.getElementById('playlist-url-input');
    const status = document.getElementById('playlist-import-status');
    const url    = input.value.trim();
    if (!url) return;

    // Detect tipo playlist
    let type = 'unknown';
    if (url.includes('youtube.com') || url.includes('youtu.be')) type = 'youtube';
    else if (url.includes('spotify.com')) type = 'spotify';

    if (type === 'unknown') {
      status.innerHTML = '<span style="color:var(--err)">❌ URL non riconosciuto. Usa YouTube o Spotify.</span>';
      return;
    }

    status.innerHTML = `<span style="color:var(--a)">⏳ Analizzando playlist ${type}...</span>`;

    try {
      const res  = await Auth.authFetch('/playlist/import', {
        method: 'POST',
        body: JSON.stringify({ url, type })
      });
      const data = await res.json();
      renderPlaylistPreview(data);
    } catch (_) {
      // Demo mode
      renderPlaylistPreview({
        name: 'Best of 80s (demo)',
        type,
        tracks: [
          { title: 'Africa', artist: 'Toto' },
          { title: 'Take On Me', artist: 'a-ha' },
          { title: 'Rio', artist: 'Duran Duran' },
          { title: 'Come On Eileen', artist: 'Dexys Midnight Runners' },
          { title: 'Total Eclipse of the Heart', artist: 'Bonnie Tyler' },
        ]
      });
    }
  }

  function renderPlaylistPreview(data) {
    const status = document.getElementById('playlist-import-status');
    const tracks = data.tracks || [];
    status.innerHTML = `
      <div class="playlist-preview">
        <div class="playlist-preview-header">
          <div class="playlist-preview-name">📋 ${data.name} — ${tracks.length} brani</div>
          <button class="playlist-load-btn" onclick="DJ.loadPlaylist()">▶ Carica e metti in coda</button>
        </div>
        <div class="playlist-tracks">
          ${tracks.slice(0, 5).map(t => `
            <div class="playlist-track">
              <span class="pt-title">${t.title}</span>
              <span class="pt-artist">${t.artist}</span>
            </div>
          `).join('')}
          ${tracks.length > 5 ? `<div class="pt-more">+ altri ${tracks.length - 5} brani...</div>` : ''}
        </div>
      </div>
    `;
    // Salva per uso successivo
    window._pendingPlaylist = data;
  }

  async function loadPlaylist() {
    const data = window._pendingPlaylist;
    if (!data) return;
    const status = document.getElementById('playlist-import-status');
    status.innerHTML = '<span style="color:var(--a)">⏳ Scaricando e accodando i brani... Potrebbe richiedere qualche minuto.</span>';

    try {
      await Auth.authFetch('/playlist/load', {
        method: 'POST',
        body: JSON.stringify(data)
      });
      status.innerHTML = `<span style="color:var(--grn)">✅ ${data.tracks.length} brani accodati con successo!</span>`;
      Chat.addActivity('📋', `Playlist "${data.name}" caricata — ${data.tracks.length} brani`, 'icon-req');
    } catch (_) {
      status.innerHTML = `<span style="color:var(--grn)">✅ Playlist caricata! (demo)</span>`;
      Chat.addActivity('📋', `Playlist "${data.name}" caricata`, 'icon-req');
    }
  }

  // ── TELEFONATE ──
  function renderCalls() {
    const list = document.getElementById('phone-list');
    if (!list) return;
    list.innerHTML = DEMO_CALLS.map(c => `
      <div class="phone-card${c.status === 'live' ? ' on-air' : ''}" style="margin-bottom:10px;">
        <div class="phone-av">👤</div>
        <div class="phone-info">
          <div class="phone-name">${c.number}</div>
          <div class="phone-num">${c.status === 'live' ? 'In onda' : 'In attesa'} · ${c.duration}</div>
          <div class="phone-status ${c.status === 'live' ? 'status-live' : 'status-wait'}">
            ${c.status === 'live' ? '● In onda' : 'In attesa'}
          </div>
        </div>
        <div class="phone-actions">
          ${c.status === 'wait' ? `
            <button class="ph-btn ph-answer">📞</button>
            <button class="ph-btn ph-onair">📡</button>
          ` : ''}
          <button class="ph-btn ph-decline">✕</button>
        </div>
      </div>
    `).join('');
    document.getElementById('phone-badge').textContent = DEMO_CALLS.length;
    document.getElementById('stat-calls').textContent = DEMO_CALLS.length;
  }

  // ── TABS ──
  function initTabs() {
    document.querySelectorAll('.dj-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        const tabId = btn.dataset.tab;
        document.querySelectorAll('.dj-tab').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        const tab = document.getElementById(tabId);
        if (tab) tab.classList.add('active');
      });
    });
  }

  // ── CONTROLLI ──
  function initControls() {
    document.getElementById('dj-go-btn').addEventListener('click', toggleLive);
    document.getElementById('dj-logout').addEventListener('click', () => { Auth.logout(); App.showPublic(); });
    document.getElementById('mic-circle').addEventListener('click', toggleMic);
    document.getElementById('log-submit').addEventListener('click', logTrack);
    document.getElementById('dj-play-btn').addEventListener('click', Player.togglePlay);
  }

  function toggleLive() {
    _isLive = !_isLive;
    const pill = document.getElementById('dj-status-pill');
    const btn  = document.getElementById('dj-go-btn');
    if (_isLive) {
      pill.className = 'dj-status-pill';
      pill.innerHTML = '<div class="live-dot-r"></div>In onda';
      btn.className = 'dj-go-btn stop';
      btn.textContent = '⏹ Stop';
    } else {
      pill.className = 'dj-status-pill offline';
      pill.innerHTML = '⏸ Offline';
      btn.className = 'dj-go-btn';
      btn.textContent = '▶ Vai in onda';
    }
  }

  function toggleMic() {
    _micHot = !_micHot;
    const circle = document.getElementById('mic-circle');
    const label  = document.getElementById('mic-label');
    const vol    = document.getElementById('mic-vol');
    if (_micHot) {
      circle.classList.add('hot');
      label.className = 'mic-hot-label';
      label.textContent = '● Microfono in onda';
      if (vol) vol.style.animation = 'vanim 0.3s ease infinite alternate';
    } else {
      circle.classList.remove('hot');
      label.className = 'mic-label-off';
      label.textContent = 'Microfono spento — tocca per attivare';
      if (vol) { vol.style.animation = 'none'; vol.style.width = '5%'; }
    }
  }

  function logTrack() {
    const title  = document.getElementById('log-title').value.trim();
    const artist = document.getElementById('log-artist').value.trim();
    const year   = document.getElementById('log-year').value;
    const source = document.getElementById('log-source').value;
    if (!title || !artist) return;

    Auth.authFetch('/tracks', {
      method: 'POST',
      body: JSON.stringify({ session_id: _sessionId, song_title: title, song_artist: artist, song_year: parseInt(year) || null, source })
    }).catch(console.error);

    const btn = document.getElementById('log-submit');
    btn.textContent = '✓ Ok!';
    btn.style.background = 'var(--grn)';
    setTimeout(() => { btn.textContent = '+ Log'; btn.style.background = ''; }, 1500);
    document.getElementById('log-title').value  = '';
    document.getElementById('log-artist').value = '';
    document.getElementById('log-year').value   = '';
    Chat.addActivity('🎵', `Brano registrato: ${title} — ${artist}`, 'icon-req');
  }

  function updateStats() {
    document.getElementById('stat-listeners').textContent = '247';
    document.getElementById('stat-listeners-d').textContent = '↑ +12';
    document.getElementById('stat-chat').textContent = '38';
  }

  return { init, acceptRequest, skipRequest, playOnDemand, loadPlaylist };

})();
