# Radio Vinile — v1.0 Rev 1.8
## Versione Base Ufficiale — 24 Marzo 2026

Questa è la versione di partenza stabile da cui sviluppare le prossime release.

### Stato al momento del freeze
- ✅ Icecast2 attivo su porta 8950
- ✅ Liquidsoap stabile con metadata ICY
- ✅ 52 brani anni 70s, 128 anni 80s, 282 anni 90s
- ✅ Sito pubblico con player funzionante
- ✅ Pannello DJ con tab Chat, Richieste, On-demand, Playlist, Mic, Telefonate
- ✅ Area riservata ascoltatori (area-riservata.html)
- ✅ Viste per ruolo: visitatore / DJ / admin
- ✅ Login ascoltatori (demo — Google/Facebook reale da implementare)

### File principali
- index.html — sito pubblico + pannello DJ
- area-riservata.html — area riservata ascoltatori
- radio.liq — script Liquidsoap
- assets/player.js — player audio con metadata
- assets/auth.js — autenticazione DJ
- assets/listener-auth.js — autenticazione ascoltatori
- assets/dj.js — pannello DJ
- assets/admin.js — sezione admin
- assets/chat.js — chat
- assets/app.js — orchestratore
- assets/style.css — tutto il CSS

### TODO prossima release (Rev 1.9)
- Login reale Google OAuth + Facebook Login
- Salvataggio utenti nel DB con data/ora login
- Fix CSS fix 4 problemi visivi segnalati (screenshot)
- Proxy API Icecast (P0 Manus)
- Telnet limitato a 127.0.0.1 (P1 Manus)

### Server
- IP: 195.231.36.12
- Directory: /opt/suimi/radiovinile/
- Dominio: radiovinile.online
