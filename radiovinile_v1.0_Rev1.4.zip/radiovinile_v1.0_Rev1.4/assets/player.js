/* ════════════════════════════════════════════════════
   RADIO VINILE — player.js
   Gestione player audio e ora in onda
   Versione: v1.0 Rev 1.4
════════════════════════════════════════════════════ */

const Player = (() => {

  const STREAM_URL   = 'https://stream.radiovinile.online/stream';
  const POLL_INTERVAL = 10000; // 10 secondi

  let _audio      = null;
  let _playing    = false;
  let _pollTimer  = null;
  let _nowPlaying = { title: 'Radio Vinile', artist: 'In onda' };

  function init() {
    _audio = document.getElementById('radio-audio');
    _audio.src = STREAM_URL;

    document.getElementById('btn-play').addEventListener('click', togglePlay);
    document.getElementById('hero-play-btn').addEventListener('click', () => {
      play();
      document.getElementById('player').scrollIntoView({ behavior: 'smooth' });
    });

    // Volume
    const volBar  = document.querySelector('.vol-bar');
    const volFill = document.getElementById('vol-fill');
    volBar.addEventListener('click', e => {
      const pct = e.offsetX / volBar.offsetWidth;
      _audio.volume = pct;
      volFill.style.width = (pct * 100) + '%';
    });

    // Polling ora in onda
    fetchNowPlaying();
    _pollTimer = setInterval(fetchNowPlaying, POLL_INTERVAL);
  }

  function play() {
    _audio.play().then(() => {
      _playing = true;
      updatePlayBtn();
      document.getElementById('hero-vinyl').style.animationPlayState = 'running';
      document.getElementById('player-disc').style.animationPlayState = 'running';
    }).catch(console.error);
  }

  function pause() {
    _audio.pause();
    _playing = false;
    updatePlayBtn();
    document.getElementById('hero-vinyl').style.animationPlayState = 'paused';
    document.getElementById('player-disc').style.animationPlayState = 'paused';
  }

  function togglePlay() {
    _playing ? pause() : play();
  }

  function updatePlayBtn() {
    const btn = document.getElementById('btn-play');
    btn.textContent = _playing ? '⏸' : '▶';
  }

  async function fetchNowPlaying() {
    try {
      const res = await fetch(`${Auth.API}/sessions/current`);
      const data = await res.json();

      const title  = data.title  || 'Radio Vinile';
      const artist = data.artist || 'In onda';
      const count  = data.listeners || '—';

      _nowPlaying = { title, artist };

      // Aggiorna UI pubblica
      document.getElementById('player-title').textContent  = title;
      document.getElementById('player-artist').textContent = artist;
      document.getElementById('live-strip-song').textContent = `${artist} — ${title}`;
      document.getElementById('listener-count').textContent = count;

      // Aggiorna on-air nel pannello DJ
      if (document.getElementById('oa-title')) {
        document.getElementById('oa-title').textContent  = title;
        document.getElementById('oa-artist').textContent = artist;
      }

    } catch (_) {
      // silenzioso — stream non ancora attivo
    }
  }

  function getNowPlaying() { return _nowPlaying; }
  function isPlaying()     { return _playing; }

  return { init, play, pause, togglePlay, fetchNowPlaying, getNowPlaying, isPlaying };

})();
