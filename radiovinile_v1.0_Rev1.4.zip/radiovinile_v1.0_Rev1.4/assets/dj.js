/* ════════════════════════════════════════════════════
   RADIO VINILE — dj.js
   Pannello DJ: coda, richieste, mic, telefonate
   Versione: v1.0 Rev 1.4
════════════════════════════════════════════════════ */

const DJ = (() => {

  let _isLive   = true;
  let _micHot   = true;
  let _sessionId = null;

  // ── DEMO DATA ──
  const DEMO_QUEUE = [
    { title: 'Africa', artist: 'Toto', year: 1982, playing: true },
    { title: 'Take On Me', artist: 'a-ha', year: 1985 },
    { title: 'Rio', artist: 'Duran Duran', year: 1982 },
    { title: "Don't You Want Me", artist: 'Human League', year: 1981 },
    { title: 'Total Eclipse of the Heart', artist: 'Bonnie Tyler', year: 1983 },
  ];

  const DEMO_REQUESTS = [
    { id: 1, song: 'Rio', artist: 'Duran Duran', year: 1982, requester: 'Giovanni_B', origin: 'web', msg: 'Lo dedico a mia moglie, era la nostra canzone 💕', time: '19:07' },
    { id: 2, song: 'Total Eclipse of the Heart', artist: 'Bonnie Tyler', year: 1983, requester: 'Lucia_F', origin: 'chat', msg: 'È il mio compleanno oggi!', time: '19:05' },
    { id: 3, song: "Don't You Want Me", artist: 'Human League', year: 1981, requester: 'Andrea_V', origin: 'whatsapp', msg: '', time: '19:01' },
  ];

  const DEMO_CALLS = [
    { id: 1, number: '+39 333 456 7890', status: 'wait', duration: '0:42' },
    { id: 2, number: '+39 347 891 2345', status: 'live', duration: '1:23' },
  ];

  function init() {
    renderQueue();
    renderRequests();
    renderCalls();
    initTabs();
    initControls();
    updateStats();
  }

  // ── CODA ──
  function renderQueue() {
    const list = document.getElementById('queue-list');
    if (!list) return;
    list.innerHTML = DEMO_QUEUE.map((t, i) => `
      <div class="queue-item${t.playing ? ' playing' : ''}">
        <div class="q-num">${t.playing ? '▶' : i + 1}</div>
        <div class="q-disc">🎵</div>
        <div class="q-info">
          <div class="q-title">${t.title}</div>
          <div class="q-artist">${t.artist}</div>
        </div>
        <div class="q-year">${t.year}</div>
      </div>
    `).join('');
  }

  // ── RICHIESTE ──
  function renderRequests() {
    const list = document.getElementById('req-list');
    if (!list) return;
    list.innerHTML = DEMO_REQUESTS.map(r => `
      <div class="req-card" id="req-${r.id}">
        <div class="req-top">
          <div>
            <div class="req-song">${r.song}</div>
            <div class="req-artist">${r.artist}${r.year ? ' · ' + r.year : ''}</div>
          </div>
          <div class="req-time">${r.time}</div>
        </div>
        ${r.msg ? `<div class="req-msg">"${r.msg}"</div>` : ''}
        <div class="req-footer">
          <div class="req-by">${r.requester} <span class="req-origin">${r.origin}</span></div>
          <div class="req-actions">
            <button class="req-btn req-btn-acc" onclick="DJ.acceptRequest(${r.id}, this)">✓ In coda</button>
            <button class="req-btn req-btn-skip" onclick="DJ.skipRequest(${r.id}, this)">Salta</button>
          </div>
        </div>
      </div>
    `).join('');
    updateReqBadge();
  }

  function acceptRequest(id, btn) {
    const card = document.getElementById('req-' + id);
    card.classList.add('accepted');
    btn.textContent = '✓ Accettata';
    btn.disabled = true;
    btn.nextElementSibling.disabled = true;
    const pending = document.querySelectorAll('.req-card:not(.accepted)').length;
    document.getElementById('req-badge').textContent = pending;
    document.getElementById('stat-req').textContent = pending;
    Chat.addActivity('🎵', `Richiesta accettata: "${card.querySelector('.req-song').textContent}"`, 'icon-req');
  }

  function skipRequest(id, btn) {
    const card = document.getElementById('req-' + id);
    card.style.opacity = '0.4';
    btn.textContent = 'Saltata';
    btn.disabled = true;
    card.querySelector('.req-btn-acc').disabled = true;
  }

  function updateReqBadge() {
    const count = DEMO_REQUESTS.length;
    document.getElementById('req-badge').textContent = count;
    document.getElementById('stat-req').textContent = count;
  }

  // ── TELEFONATE ──
  function renderCalls() {
    const list = document.getElementById('phone-list');
    if (!list) return;
    list.innerHTML = DEMO_CALLS.map(c => `
      <div class="phone-card${c.status === 'live' ? ' on-air' : ''}" style="margin-bottom:10px;">
        <div class="phone-av">👤</div>
        <div class="phone-info">
          <div class="phone-name">${c.number}</div>
          <div class="phone-num">${c.status === 'live' ? 'In onda' : 'In attesa'} · ${c.duration}</div>
          <div class="phone-status ${c.status === 'live' ? 'status-live' : 'status-wait'}">
            ${c.status === 'live' ? '● In onda' : 'In attesa'}
          </div>
        </div>
        <div class="phone-actions">
          ${c.status === 'wait' ? `
            <button class="ph-btn ph-answer">📞</button>
            <button class="ph-btn ph-onair" onclick="Chat.addActivity('📞','Telefonata messa in onda da ${c.number}','icon-phone')">📡</button>
          ` : ''}
          <button class="ph-btn ph-decline">✕</button>
        </div>
      </div>
    `).join('');
    document.getElementById('phone-badge').textContent = DEMO_CALLS.length;
    document.getElementById('stat-calls').textContent = DEMO_CALLS.length;
  }

  // ── TABS ──
  function initTabs() {
    document.querySelectorAll('.dj-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        const tabId = btn.dataset.tab;
        document.querySelectorAll('.dj-tab').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(tabId).classList.add('active');
      });
    });
  }

  // ── CONTROLLI ──
  function initControls() {
    // Go live / Stop
    document.getElementById('dj-go-btn').addEventListener('click', toggleLive);
    // Logout
    document.getElementById('dj-logout').addEventListener('click', () => {
      Auth.logout();
      App.showPublic();
    });
    // Mic
    document.getElementById('mic-circle').addEventListener('click', toggleMic);
    // Log brano
    document.getElementById('log-submit').addEventListener('click', logTrack);
    // DJ play/pause
    document.getElementById('dj-play-btn').addEventListener('click', Player.togglePlay);
  }

  function toggleLive() {
    _isLive = !_isLive;
    const pill = document.getElementById('dj-status-pill');
    const btn  = document.getElementById('dj-go-btn');
    if (_isLive) {
      pill.className = 'dj-status-pill';
      pill.innerHTML = '<div class="live-dot-r"></div>In onda';
      btn.className = 'dj-go-btn stop';
      btn.textContent = '⏹ Stop';
    } else {
      pill.className = 'dj-status-pill offline';
      pill.innerHTML = '⏸ Offline';
      btn.className = 'dj-go-btn';
      btn.textContent = '▶ Vai in onda';
    }
  }

  function toggleMic() {
    _micHot = !_micHot;
    const circle = document.getElementById('mic-circle');
    const label  = document.getElementById('mic-label');
    const vol    = document.getElementById('mic-vol');
    if (_micHot) {
      circle.classList.add('hot');
      label.className = 'mic-hot-label';
      label.textContent = '● Microfono in onda';
      if (vol) vol.style.animation = 'vanim 0.3s ease infinite alternate';
    } else {
      circle.classList.remove('hot');
      label.className = 'mic-label-off';
      label.textContent = 'Microfono spento — tocca per attivare';
      if (vol) { vol.style.animation = 'none'; vol.style.width = '5%'; }
    }
  }

  function logTrack() {
    const title  = document.getElementById('log-title').value.trim();
    const artist = document.getElementById('log-artist').value.trim();
    const year   = document.getElementById('log-year').value;
    const source = document.getElementById('log-source').value;
    if (!title || !artist) return;

    // POST all'API (asincrono, non blocca)
    Auth.authFetch('/tracks', {
      method: 'POST',
      body: JSON.stringify({ session_id: _sessionId, song_title: title, song_artist: artist, song_year: parseInt(year) || null, source })
    }).catch(console.error);

    // Feedback visivo
    const btn = document.getElementById('log-submit');
    btn.textContent = '✓ Ok!';
    btn.style.background = 'var(--grn)';
    setTimeout(() => { btn.textContent = '+ Log'; btn.style.background = ''; }, 1500);

    // Pulisci campi
    document.getElementById('log-title').value  = '';
    document.getElementById('log-artist').value = '';
    document.getElementById('log-year').value   = '';

    Chat.addActivity('🎵', `Brano registrato: ${title} — ${artist}`, 'icon-req');
  }

  function updateStats() {
    document.getElementById('stat-listeners').textContent = '247';
    document.getElementById('stat-listeners-d').textContent = '↑ +12';
    document.getElementById('stat-chat').textContent = '38';
  }

  return { init, acceptRequest, skipRequest };

})();
