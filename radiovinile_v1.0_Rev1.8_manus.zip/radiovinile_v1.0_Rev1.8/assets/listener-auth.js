/* ════════════════════════════════════════════════════
   RADIO VINILE — listener-auth.js
   Login ascoltatori via Google / Facebook
   Gestione preferiti in localStorage
   Versione: v1.0 Rev 1.7
════════════════════════════════════════════════════ */

const ListenerAuth = (() => {

  const USER_KEY = 'rv_listener';
  const FAVS_KEY = 'rv_favorites';

  let _user = JSON.parse(localStorage.getItem(USER_KEY) || 'null');

  function getUser()      { return _user; }
  function isLoggedIn()   { return !!_user; }

  function getFavorites() {
    return JSON.parse(localStorage.getItem(FAVS_KEY) || '[]');
  }

  function saveFavorite(track) {
    const favs = getFavorites();
    const exists = favs.some(f => f.title === track.title && f.artist === track.artist);
    if (!exists) {
      favs.unshift({ ...track, savedAt: new Date().toISOString() });
      localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    }
  }

  function removeFavorite(track) {
    const favs = getFavorites().filter(f => !(f.title === track.title && f.artist === track.artist));
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
  }

  // ── LOGIN GOOGLE ──
  function loginWithGoogle() {
    // Simulazione — in produzione usa Google OAuth2
    // Per ora usa un nome demo finché non integriamo Firebase Auth
    _simulateLogin('google');
  }

  // ── LOGIN FACEBOOK ──
  function loginWithFacebook() {
    _simulateLogin('facebook');
  }

  // ── LOGIN EMAIL ──
  function loginWithEmail() {
    const email = prompt('Inserisci la tua email:');
    if (!email || !email.includes('@')) return;
    const name = email.split('@')[0];
    _setUser({ name, email, provider: 'email', avatar: '✉️' });
    _closeModal();
    _onLoginSuccess();
  }

  function _simulateLogin(provider) {
    // Demo: simula login con nome casuale
    // In produzione: integra Firebase Auth o OAuth diretto
    const names = ['Marco', 'Giulia', 'Luca', 'Sara', 'Giovanni', 'Valentina'];
    const name = names[Math.floor(Math.random() * names.length)];
    const icons = { google: '🇬', facebook: '👤' };
    _setUser({
      name,
      email: name.toLowerCase() + '@demo.com',
      provider,
      avatar: icons[provider] || '👤'
    });
    _closeModal();
    _onLoginSuccess();
  }

  function _setUser(user) {
    _user = user;
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function logout() {
    _user = null;
    localStorage.removeItem(USER_KEY);
    _updateNavUI();
  }

  function _closeModal() {
    const modal = document.getElementById('listener-login-modal');
    if (modal) modal.classList.add('hidden');
  }

  function _onLoginSuccess() {
    _updateNavUI();
    App.showToast(`Benvenuto/a ${_user.name}! ❤️`);
    if (typeof Chat !== 'undefined' && Chat.welcomeUser) Chat.welcomeUser(_user.name);
    // Dopo login, esegui il like sul brano corrente
    Player.handleLike();
  }

  function _updateNavUI() {
    const info    = document.getElementById('nav-listener-info');
    const nameEl  = document.getElementById('nav-listener-name');
    if (!info) return;
    if (_user) {
      info.classList.remove('hidden');
      if (nameEl) nameEl.textContent = _user.name;
    } else {
      info.classList.add('hidden');
    }
  }

  function init() {
    // Bottoni modal login
    const googleBtn = document.getElementById('login-google-btn');
    const fbBtn     = document.getElementById('login-facebook-btn');
    const emailBtn  = document.getElementById('login-email-btn');
    const closeBtn  = document.getElementById('listener-login-close');

    if (googleBtn)   googleBtn.addEventListener('click', loginWithGoogle);
    if (fbBtn)       fbBtn.addEventListener('click', loginWithFacebook);
    if (emailBtn)    emailBtn.addEventListener('click', loginWithEmail);
    if (closeBtn)    closeBtn.addEventListener('click', () => {
      document.getElementById('listener-login-modal').classList.add('hidden');
    });

    // Chiudi modal cliccando fuori
    const modal = document.getElementById('listener-login-modal');
    if (modal) {
      modal.addEventListener('click', e => {
        if (e.target === modal) modal.classList.add('hidden');
      });
    }

    // Bottone preferiti in navbar
    const favsBtn = document.getElementById('nav-favorites-btn');
    if (favsBtn) favsBtn.addEventListener('click', showFavorites);

    // Logout ascoltatore
    const logoutBtn = document.getElementById('nav-listener-logout');
    if (logoutBtn) logoutBtn.addEventListener('click', () => {
      logout();
      App.showToast('Disconnesso');
    });

    // Chiudi modal preferiti
    const favsClose = document.getElementById('favorites-close');
    if (favsClose) favsClose.addEventListener('click', () => {
      document.getElementById('favorites-modal').classList.add('hidden');
    });

    // Aggiorna UI se già loggato
    if (_user) _updateNavUI();
  }

  function showFavorites() {
    const modal = document.getElementById('favorites-modal');
    const list  = document.getElementById('favorites-list');
    const empty = document.getElementById('favorites-empty');
    const favs  = getFavorites();

    if (!modal || !list) return;

    if (favs.length === 0) {
      list.innerHTML = '';
      if (empty) empty.classList.remove('hidden');
    } else {
      if (empty) empty.classList.add('hidden');
      list.innerHTML = favs.map((f, i) => `
        <div class="fav-item">
          <div class="fav-disc">🎵</div>
          <div class="fav-info">
            <div class="fav-title">${f.title}</div>
            <div class="fav-artist">${f.artist}</div>
            <div class="fav-date">${new Date(f.savedAt).toLocaleDateString('it-IT')}</div>
          </div>
          <button class="fav-remove" onclick="ListenerAuth.removeFavoriteByIndex(${i})">✕</button>
        </div>
      `).join('');
    }

    modal.classList.remove('hidden');
  }

  function removeFavoriteByIndex(index) {
    const favs = getFavorites();
    favs.splice(index, 1);
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    showFavorites(); // Ricarica la lista
    App.showToast('Rimosso dai preferiti');
  }

  return { init, getUser, isLoggedIn, getFavorites, saveFavorite, removeFavorite, removeFavoriteByIndex, logout, showFavorites, loginWithGoogle, loginWithFacebook };

})();
