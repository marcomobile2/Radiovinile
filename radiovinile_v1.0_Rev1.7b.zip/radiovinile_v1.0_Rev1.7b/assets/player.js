/* RADIO VINILE — player.js — v1.0 Rev 1.7b */
const Player = (() => {
  const STREAM_URL = 'https://radiovinile.online/stream';
  const POLL_INTERVAL = 10000;
  let _audio = null, _playing = false, _loading = false, _liked = false;
  let _volume = 0.8, _startTime = null, _timerInterval = null;
  let _nowPlaying = { title: 'Radio Vinile', artist: 'In onda', year: '' };

  function init() {
    _audio = document.getElementById('radio-audio');
    _audio.volume = _volume;

    _audio.addEventListener('playing', () => {
      _loading = false; _playing = true;
      updatePlayBtn(); setVinylSpin(true); setStreamStatus(true); hideStreamError(); startTimer();
    });
    _audio.addEventListener('pause', () => { _playing = false; updatePlayBtn(); setVinylSpin(false); stopTimer(); });
    _audio.addEventListener('waiting', () => { _loading = true; updatePlayBtn(); });
    _audio.addEventListener('error', () => {
      _loading = false; _playing = false;
      updatePlayBtn(); setVinylSpin(false); setStreamStatus(false); showStreamError(); stopTimer();
    });

    document.getElementById('btn-play').addEventListener('click', togglePlay);
    document.getElementById('hero-play-btn').addEventListener('click', () => {
      play(); document.getElementById('player').scrollIntoView({ behavior: 'smooth' });
    });

    // ❤️ Cuore
    const likeBtn = document.getElementById('btn-like');
    if (likeBtn) likeBtn.addEventListener('click', () => {
      if (typeof ListenerAuth === 'undefined') return;
      if (!ListenerAuth.isLoggedIn()) {
        document.getElementById('listener-login-modal').classList.remove('hidden');
      } else {
        _liked = !_liked;
        likeBtn.textContent = _liked ? '❤️' : '♥';
        likeBtn.classList.toggle('liked', _liked);
        if (_liked) { ListenerAuth.saveFavorite(_nowPlaying); App.showToast('❤️ "' + _nowPlaying.title + '" salvato!'); }
        else        { ListenerAuth.removeFavorite(_nowPlaying); App.showToast('Rimosso dai preferiti'); }
      }
    });

    // 💿 Condividi
    const shareBtn = document.getElementById('btn-share');
    if (shareBtn) shareBtn.addEventListener('click', () => {
      const np = _nowPlaying;
      const yr = np.year ? "'" + String(np.year).slice(-2) + ' · ' : '';
      const text = '💿 Sto ascoltando ' + yr + np.artist + ' — ' + np.title + ' su Radio Vinile\nhttps://radiovinile.online';
      if (navigator.share) navigator.share({ title: 'Radio Vinile 💿', text, url: 'https://radiovinile.online' });
      else navigator.clipboard.writeText(text).then(() => App.showToast('💿 Copiato negli appunti!'));
    });

    // Volume
    initVolume();
    const vf = document.getElementById('vol-fill');
    if (vf) vf.style.width = (_volume * 100) + '%';

    fetchNowPlaying();
    setInterval(fetchNowPlaying, POLL_INTERVAL);
  }

  function initVolume() {
    const volBar = document.querySelector('.vol-bar');
    const volFill = document.getElementById('vol-fill');
    if (!volBar || !volFill) return;
    const setVol = (clientX) => {
      const rect = volBar.getBoundingClientRect();
      const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      _volume = pct; _audio.volume = pct; volFill.style.width = (pct * 100) + '%';
    };
    let drag = false;
    volBar.addEventListener('mousedown', e => { drag = true; setVol(e.clientX); });
    window.addEventListener('mousemove', e => { if (drag) setVol(e.clientX); });
    window.addEventListener('mouseup', () => drag = false);
    volBar.addEventListener('click', e => setVol(e.clientX));
    volBar.addEventListener('touchstart', e => setVol(e.touches[0].clientX), { passive: true });
    volBar.addEventListener('touchmove', e => { e.preventDefault(); setVol(e.touches[0].clientX); }, { passive: false });
  }

  function startTimer() {
    stopTimer(); _startTime = Date.now();
    _timerInterval = setInterval(updateTimer, 1000); updateTimer();
  }
  function stopTimer() {
    if (_timerInterval) { clearInterval(_timerInterval); _timerInterval = null; }
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    set('time-current', '0:00'); set('time-total', '0:00');
    const f = document.getElementById('progress-fill'); if (f) f.style.width = '0%';
  }
  function updateTimer() {
    if (!_startTime) return;
    const s = Math.floor((Date.now() - _startTime) / 1000);
    const cur = document.getElementById('time-current'); if (cur) cur.textContent = fmt(s);
    const tot = document.getElementById('time-total');   if (tot) tot.textContent = 'LIVE';
    const fill = document.getElementById('progress-fill');
    if (fill) fill.style.width = Math.min(100, (s % 240) / 240 * 100) + '%';
  }
  function fmt(s) { return Math.floor(s/60) + ':' + String(s%60).padStart(2,'0'); }

  function play() {
    if (_loading) return;
    if (!_audio.src || _audio.src === window.location.href) _audio.src = STREAM_URL;
    _loading = true; updatePlayBtn();
    _audio.play().catch(() => { _loading = false; _playing = false; updatePlayBtn(); showStreamError('Impossibile avviare lo stream. Riprova.'); });
  }
  function pause() { _audio.pause(); _playing = false; _loading = false; updatePlayBtn(); setVinylSpin(false); setStreamStatus(false); stopTimer(); }
  function togglePlay() { _playing ? pause() : play(); }

  function updatePlayBtn() {
    const icon = _loading ? '⏳' : (_playing ? '⏸' : '▶');
    [['btn-play',icon],['hero-play-btn',_playing?'⏸ In ascolto':'▶ Ascolta ora'],['dj-play-btn',_playing?'⏸':'▶']].forEach(([id,v])=>{ const e=document.getElementById(id); if(e) e.textContent=v; });
  }
  function setVinylSpin(r) {
    ['hero-vinyl','player-disc','on-air-disc'].forEach(id=>{ const e=document.getElementById(id); if(e) e.style.animationPlayState=r?'running':'paused'; });
  }
  function setStreamStatus(online) {
    const el = document.getElementById('ver-stream-status'); if (!el) return;
    el.textContent = online ? '🔴 In onda' : '⏸ Stream offline';
    el.style.color = online ? 'var(--live)' : 'var(--t3)';
  }
  function showStreamError(msg) {
    let el = document.getElementById('stream-error-banner');
    if (!el) { el = document.createElement('div'); el.id='stream-error-banner'; el.className='stream-error-banner'; const pw=document.querySelector('.player-wrap'); if(pw) pw.insertBefore(el,pw.firstChild); }
    el.textContent = msg || '⚠️ Stream non disponibile — riprova tra qualche secondo';
    el.classList.remove('hidden');
  }
  function hideStreamError() { const el=document.getElementById('stream-error-banner'); if(el) el.classList.add('hidden'); }

  async function fetchNowPlaying() {
    try {
      const res = await fetch('https://api.radiovinile.online/api/sessions/current');
      const data = await res.json();
      const title = data.title||'Radio Vinile', artist = data.artist||'In onda', year = data.year||'', count = data.listeners!==undefined?data.listeners:'—';
      _nowPlaying = { title, artist, year };
      const yr = year ? "'"+String(year).slice(-2)+' · ' : '';
      const label = yr + artist + ' · ' + title;
      const set = (id,v)=>{ const e=document.getElementById(id); if(e) e.textContent=v; };
      set('player-title', label); set('player-artist','');
      set('live-strip-song', artist+' — '+title);
      set('listener-count', count); set('oa-title',title); set('oa-artist',artist);
      if (typeof ListenerAuth!=='undefined' && ListenerAuth.isLoggedIn()) {
        const isFav = ListenerAuth.getFavorites().some(f=>f.title===title&&f.artist===artist);
        const btn = document.getElementById('btn-like');
        if (btn) { _liked=isFav; btn.textContent=isFav?'❤️':'♥'; btn.classList.toggle('liked',isFav); }
      }
    } catch(_) {}
  }

  function isPlaying()     { return _playing; }
  function getNowPlaying() { return _nowPlaying; }
  return { init, play, pause, togglePlay, fetchNowPlaying, isPlaying, getNowPlaying };
})();
