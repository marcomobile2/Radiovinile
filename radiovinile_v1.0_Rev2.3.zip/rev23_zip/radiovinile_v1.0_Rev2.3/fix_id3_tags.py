#!/usr/bin/env python3
"""
================================================================================
RADIO VINILE — fix_id3_tags.py
Corregge i tag ID3 di tutti gli MP3 leggendo il nome file.
Arricchisce i tag con anno reale da MusicBrainz.

Formati nome file supportati:
  1. "NA - Artista - Titolo.mp3"
  2. "Artista - Titolo (Anno).mp3"
  3. "Artista - Titolo.mp3"
  4. "ANNO - Artista - Titolo.mp3"

Uso:
  python3 fix_id3_tags.py [--dry-run] [--dir /opt/radiovinile/music]
  python3 fix_id3_tags.py [--dir /opt/radiovinile/music/80s]

Fix Rev 2.3:
  - Corretto bug critico: urllib.request non ha .parse
    Ora si importano separatamente urllib.request e urllib.parse
  - Aggiunto fallback robusto se MusicBrainz non risponde
  - Migliorata pulizia titoli YouTube (suffissi aggiuntivi)
================================================================================
"""

import os, re, sys, time, argparse, json
from pathlib import Path

try:
    from mutagen.id3 import ID3, TIT2, TPE1, TDRC, ID3NoHeaderError
    from mutagen.mp3 import MP3
except ImportError:
    print("❌ Installa mutagen: pip install mutagen --break-system-packages")
    sys.exit(1)

# ── IMPORT URLLIB CORRETTO ────────────────────────────────────────────────────
# FIX Rev 2.3: urllib.request e urllib.parse sono moduli SEPARATI
# NON si può fare urllib.request.parse — questo causava il crash
try:
    import urllib.request as _urllib_req
    import urllib.parse   as _urllib_parse
    HAS_URLLIB = True
except ImportError:
    HAS_URLLIB = False

# ── MusicBrainz ───────────────────────────────────────────────────────────────
_mb_cache = {}

def get_year_from_musicbrainz(artist: str, title: str) -> str:
    """Cerca l'anno di pubblicazione reale su MusicBrainz."""
    if not HAS_URLLIB:
        return ""
    key = f"{artist.lower()}|{title.lower()}"
    if key in _mb_cache:
        return _mb_cache[key]

    # Pulisci titolo da suffissi YouTube
    title_clean = re.sub(
        r'\s*[\(\[](Official.*?|HD|HQ|Video.*?|Remaster.*?|Live.*?|Audio.*?|Lyric.*?)[\)\]]',
        '', title, flags=re.IGNORECASE
    ).strip()
    title_clean = re.sub(
        r'\s*-\s*(Official.*|HD.*|HQ.*|Video.*|Remaster.*)$',
        '', title_clean, flags=re.IGNORECASE
    ).strip()

    query = f'recording:"{title_clean}" AND artist:"{artist}"'
    # FIX: usa _urllib_parse.quote() invece di _urllib.parse.quote()
    url = (
        f'https://musicbrainz.org/ws/2/recording'
        f'?query={_urllib_parse.quote(query)}&limit=3&fmt=json'
    )

    try:
        req = _urllib_req.Request(url, headers={
            'User-Agent': 'RadioVinile/2.3 (radiovinile.online)'
        })
        with _urllib_req.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode())

        recordings = data.get('recordings', [])
        best_year  = ""

        for rec in recordings:
            for release in rec.get('releases', []):
                d = release.get('date', '')
                if d and len(d) >= 4:
                    try:
                        yr = int(d[:4])
                        # Accetta solo anni nel range radio (1960-1999)
                        if 1960 <= yr <= 1999:
                            if not best_year or yr < int(best_year):
                                best_year = str(yr)
                    except ValueError:
                        pass

        _mb_cache[key] = best_year
        # Rate limit MusicBrainz: max 1 req/sec
        time.sleep(1.1)
        return best_year

    except Exception as e:
        _mb_cache[key] = ""
        return ""

# ── PARSER NOME FILE ──────────────────────────────────────────────────────────
def parse_filename(fname: str) -> dict:
    """Estrae artista, titolo e anno dal nome file."""
    name = fname.replace('.mp3', '')

    # Rimuovi prefisso "NA - "
    name = re.sub(r'^NA\s*-\s*', '', name).strip()

    # Cerca anno nel nome (es. 1984, (1984), [1984])
    year_match = re.search(r'[\(\[]?(19[6-9]\d)[\)\]]?', name)
    year_from_name = year_match.group(1) if year_match else ""

    # Rimuovi suffissi YouTube rumorosi
    noise = [
        r'\s*\(Official Music Video\)', r'\s*\(Official Video\)',
        r'\s*\[Official.*?\]', r'\s*\(.*?Official.*?\)',
        r'\s*\(HD.*?\)', r'\s*\[HD.*?\]', r'\s*HD$',
        r'\s*\(HQ.*?\)', r'\s*\[HQ.*?\]',
        r'\s*\(Remaster.*?\)', r'\s*\[Remaster.*?\]',
        r'\s*\(19\d\d\)', r'\s*\[19\d\d\]',
        r'\s*\(\d{4}\)', r'\s*\[\d{4}\]',
        r'\s*-\s*Official.*$', r'\s*-\s*HD.*$',
        r'\s*\(4K.*?\)', r'\s*\(Audio.*?\)',
        r'\s*\(Visualis.*?\)', r'\s*\(Lyric.*?\)',
        r'\s*\(Live.*?\)', r'\s*\[Live.*?\]',
        r'\s*⧸.*$',
    ]
    for pattern in noise:
        name = re.sub(pattern, '', name, flags=re.IGNORECASE).strip()
    name = name.strip(' -')

    # Split artista - titolo
    parts = [p.strip() for p in name.split(' - ', 1)]
    if len(parts) == 2:
        artist, title = parts
    else:
        artist, title = 'Radio Vinile', name

    return {'artist': artist, 'title': title, 'year_from_name': year_from_name}

# ── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='Fix tag ID3 MP3 con arricchimento MusicBrainz')
    parser.add_argument('--dry-run', action='store_true', help='Mostra modifiche senza applicarle')
    parser.add_argument('--dir', default='/opt/radiovinile/music', help='Directory musica')
    parser.add_argument('--no-musicbrainz', action='store_true', help='Salta MusicBrainz (più veloce)')
    args = parser.parse_args()

    music_dir = Path(args.dir)
    if not music_dir.exists():
        print(f"❌ Directory non trovata: {music_dir}")
        sys.exit(1)

    # Raccoglie tutti gli MP3
    mp3_files = list(music_dir.rglob('*.mp3'))
    total     = len(mp3_files)

    if args.dry_run:
        print(f"[DRY RUN] Trovati {total} file MP3 in {music_dir}")
    else:
        print(f"Trovati {total} file MP3 in {music_dir}")
        if not args.no_musicbrainz:
            print("⚠️  MusicBrainz attivo — potrebbe richiedere diversi minuti per molti file")

    print("=" * 70)

    stats = {'updated': 0, 'already_ok': 0, 'dry_run': 0, 'skipped': 0, 'errors': 0}

    for i, fpath in enumerate(sorted(mp3_files), 1):
        fname = fpath.name
        try:
            # Leggi tag esistenti
            try:
                tags = ID3(str(fpath))
            except ID3NoHeaderError:
                tags = ID3()

            existing_title  = str(tags.get('TIT2', '')).strip()
            existing_artist = str(tags.get('TPE1', '')).strip()
            existing_year   = str(tags.get('TDRC', '')).strip()

            # Parsa nome file
            parsed = parse_filename(fname)
            new_artist = parsed['artist']
            new_title  = parsed['title']
            year_name  = parsed['year_from_name']

            # Determina anno migliore:
            # 1. Anno dal nome file (se valido 1960-1999)
            # 2. Anno da MusicBrainz (se anno mancante o > 1999)
            # 3. Anno esistente nei tag (se valido, cioè <= 1999)
            new_year = ""

            if year_name and 1960 <= int(year_name) <= 1999:
                new_year = year_name
            elif not args.no_musicbrainz:
                # Controlla se anno esistente è già buono
                existing_year_int = 0
                if existing_year and len(existing_year) >= 4:
                    try:
                        existing_year_int = int(existing_year[:4])
                    except ValueError:
                        pass

                if existing_year_int and 1960 <= existing_year_int <= 1999:
                    new_year = str(existing_year_int)
                else:
                    # Cerca su MusicBrainz solo se anno mancante o sbagliato
                    print(f"  🔍 MusicBrainz [{i}/{total}]: {new_artist} — {new_title[:40]}...", end='\r')
                    sys.stdout.flush()
                    mb_year = get_year_from_musicbrainz(new_artist, new_title)
                    if mb_year:
                        new_year = mb_year
                    elif existing_year_int:
                        new_year = str(existing_year_int)
            elif existing_year and len(existing_year) >= 4:
                try:
                    yr = int(existing_year[:4])
                    if 1960 <= yr <= 1999:
                        new_year = str(yr)
                except ValueError:
                    pass

            # Verifica se già ok (non sovrascrivere se tutto corretto)
            year_ok   = (existing_year[:4] == new_year) if (new_year and len(existing_year) >= 4) else (not new_year)
            artist_ok = existing_artist == new_artist
            title_ok  = existing_title == new_title

            if artist_ok and title_ok and year_ok and existing_artist and existing_title:
                stats['already_ok'] += 1
                continue

            if args.dry_run:
                print(f"  📋 DRY-RUN: {new_artist} — {new_title}{' (' + new_year + ')' if new_year else ''}")
                print(f"     File: {fname}")
                stats['dry_run'] += 1
                continue

            # Scrivi tag
            tags.add(TIT2(encoding=3, text=new_title))
            tags.add(TPE1(encoding=3, text=new_artist))
            if new_year:
                tags.add(TDRC(encoding=3, text=new_year))
            tags.save(str(fpath))

            year_str = f" ({new_year})" if new_year else ""
            print(f"  ✅ AGGIORNATO: {new_artist} — {new_title}{year_str}")
            print(f"     File: {fname}")
            stats['updated'] += 1

        except Exception as e:
            stats['errors'] += 1
            print(f"  ❌ ERRORE: {fname[:60]} — {e}")

    print("=" * 70)
    print(f"Riepilogo: {stats['updated']} aggiornati | {stats['already_ok']} già OK | "
          f"{stats['dry_run']} dry-run | {stats['skipped']} saltati | {stats['errors']} errori")

if __name__ == '__main__':
    main()
