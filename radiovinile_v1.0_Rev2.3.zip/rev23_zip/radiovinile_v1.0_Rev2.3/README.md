# Radio Vinile — v1.0 Rev 2.3

**Data**: 24 Marzo 2026  
**Server**: 195.231.36.12 (Aruba VPS, Ubuntu 24.04)  
**Dominio**: [radiovinile.online](https://radiovinile.online)

---

## Stack Tecnico

| Componente | Tecnologia | Porta |
|---|---|---|
| Backend API | Python 3.x + FastAPI 2.3.0 | 8001 |
| Database | SQLite (`radiovinile.db`) | — |
| Streaming | Liquidsoap 2.2.4 + Icecast2 | 8950 |
| Reverse Proxy | Caddy (HTTPS auto) | 443/80 |
| AI Gossip | Claude claude-haiku-4-5-20251001 | — |
| Metadata | MusicBrainz API | — |

---

## Struttura File

```
/opt/radiovinile/
├── api.py                    # FastAPI backend (Rev 2.3)
├── radio.liq                 # Liquidsoap config
├── fix_id3_tags.py           # Fix tag ID3 + MusicBrainz (Rev 2.3)
├── download_music.sh         # Download playlist YouTube (Rev 2.3)
├── check_year.py             # Filtro anno brani
├── index.html                # Pagina pubblica + pannello DJ
├── area-riservata.html       # Area listener
├── radiovinile.db            # Database SQLite
├── assets/
│   ├── app.js                # Orchestratore principale
│   ├── auth.js               # Autenticazione JWT
│   ├── player.js             # Player audio
│   ├── dj.js                 # Pannello DJ + gossip
│   ├── admin.js              # Pannello admin
│   ├── chat.js               # Chat real-time
│   ├── listener-auth.js      # OAuth listener
│   └── style.css             # Stili globali
├── music/
│   ├── 70s/                  # MP3 anni 70
│   ├── 80s/                  # MP3 anni 80
│   └── 90s/                  # MP3 anni 90
└── backups/
    └── pre_rev23/            # Backup pre-deploy Rev 2.3
```

---

## Novità Rev 2.3

### TASK 1 — Fix download_music.sh
- Aggiunto `--yes-playlist` per forzare download intera playlist
- Aggiunto `--no-abort-on-error` per continuare su video bloccati
- Formato output: `NA - %(uploader)s - %(title)s.%(ext)s`
- Aggiunto `--sleep-interval 1` per rispettare rate limit YouTube
- Aggiunto `--extractor-args "youtube:player_client=android"`

### TASK 2 — Config admin verificato
- Tab ⚙️ Config: classe `admin-only hidden` corretta
- Bottone Salva → `POST /api/config` ✅
- Bottone Testa → `GET /api/config/test-anthropic` ✅

### TASK 3 — Fix bug critico fix_id3_tags.py
- **Bug**: `urllib.request` non ha attributo `.parse`
- **Fix**: importati separatamente `urllib.request` e `urllib.parse`
- MusicBrainz ora funziona correttamente

### TASK 4 — Gossip DJ verificato
- `fetchTrackInfo()` ogni 12s ✅
- `<div id="track-card-now">` presente ✅
- `POST /api/track/info` con Claude AI + MusicBrainz ✅

### TASK 5 — Versioni aggiornate
Tutti i file ora mostrano `v1.0 Rev 2.3`.

---

## Uso download_music.sh

```bash
# Scarica una playlist YouTube nella cartella 80s
./download_music.sh "https://youtube.com/playlist?list=PLxxx" 80s

# Scarica nella cartella 70s
./download_music.sh "https://youtube.com/playlist?list=PLyyy" 70s
```

---

## Credenziali Demo

| Ruolo | Username | Password |
|---|---|---|
| Admin | admin | (configurato sul server) |
| DJ | dj1 | (configurato sul server) |

---

## Servizi Systemd

```bash
systemctl status liquidsoap.service
systemctl status radiovinile-api.service
systemctl restart liquidsoap.service
systemctl restart radiovinile-api.service
```
