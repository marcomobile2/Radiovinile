/* ════════════════════════════════════════════════════
   RADIO VINILE — auth.js
   Gestione autenticazione DJ/Admin
   Versione: v1.0 Rev 1.4
════════════════════════════════════════════════════ */

const Auth = (() => {

  const API = 'https://api.radiovinile.online/api';
  const TOKEN_KEY = 'rv_token';
  const DJ_KEY    = 'rv_dj';

  let _token = localStorage.getItem(TOKEN_KEY);
  let _dj    = JSON.parse(localStorage.getItem(DJ_KEY) || 'null');

  // ── GETTERS ──
  function getToken()   { return _token; }
  function getDJ()      { return _dj; }
  function isLoggedIn() { return !!_token; }
  function isAdmin()    { return _dj?.role === 'admin'; }
  function isDJ()       { return _dj?.role === 'dj' || isAdmin(); }

  // ── LOGIN ──
  async function login(username, password) {
    const res = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!res.ok) throw new Error('Credenziali non valide');
    const data = await res.json();
    _token = data.token;
    _dj    = { id: data.dj_id, display_name: data.display_name, role: data.role };
    localStorage.setItem(TOKEN_KEY, _token);
    localStorage.setItem(DJ_KEY, JSON.stringify(_dj));
    return _dj;
  }

  // ── LOGOUT ──
  function logout() {
    _token = null;
    _dj    = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(DJ_KEY);
  }

  // ── FETCH AUTENTICATO ──
  async function authFetch(endpoint, opts = {}) {
    const res = await fetch(`${API}${endpoint}`, {
      ...opts,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${_token}`,
        ...(opts.headers || {})
      }
    });
    if (res.status === 401) {
      logout();
      App.showPublic();
      throw new Error('Sessione scaduta');
    }
    return res;
  }

  return { getToken, getDJ, isLoggedIn, isAdmin, isDJ, login, logout, authFetch, API };

})();
