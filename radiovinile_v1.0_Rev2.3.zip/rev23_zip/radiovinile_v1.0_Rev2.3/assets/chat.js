/* ════════════════════════════════════════════════════
   RADIO VINILE — chat.js
   Chat pubblica e DJ in tempo reale
   Versione: v1.0 Rev 1.4
════════════════════════════════════════════════════ */

const Chat = (() => {

  // Demo messages (finché Firebase non è integrato)
  const DEMO_MESSAGES = [
    { id: 1, text: "Buonasera a tutti! Questa sera andiamo a fondo negli anni 80 🎶", user: "Marco · DJ", avatar: "🎙️", isStaff: true },
    { id: 2, text: "Finalmente! Aspettavo questa serata tutta la settimana ❤️", user: "Giulia_R", avatar: "😊" },
    { id: 3, text: "Africa dei Toto è leggendaria!", user: "Rocco78", avatar: "🎸" },
    { id: 4, text: "Ho il vinile originale del 1982 sul piatto 🎯", user: "Marco · DJ", avatar: "🎙️", isStaff: true },
    { id: 5, text: "Puoi mettere qualcosa di Duran Duran?", user: "Giovanni_B", avatar: "👋" },
  ];

  let _messages = [...DEMO_MESSAGES];
  let _onlineCount = 38;

  function init() {
    renderPublic();
    renderDJ();

    document.getElementById('chat-send').addEventListener('click', sendPublic);
    document.getElementById('chat-input').addEventListener('keydown', e => {
      if (e.key === 'Enter') sendPublic();
    });

    const djSend = document.getElementById('dj-chat-send');
    const djInput = document.getElementById('dj-chat-input');
    if (djSend) {
      djSend.addEventListener('click', sendDJ);
      djInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendDJ(); });
    }

    // Aggiorna contatore
    document.getElementById('online-count').textContent = `${_onlineCount} online`;
  }

  function renderPublic() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    container.innerHTML = '';
    _messages.forEach(m => container.appendChild(buildMsgEl(m, false)));
    container.scrollTop = container.scrollHeight;
  }

  function renderDJ() {
    const container = document.getElementById('dj-chat-messages');
    if (!container) return;
    container.innerHTML = '';
    _messages.forEach(m => container.appendChild(buildMsgEl(m, true)));
    container.scrollTop = container.scrollHeight;
  }

  function buildMsgEl(msg, isDJView) {
    const div = document.createElement('div');
    div.className = 'chat-msg' + (msg.isStaff && isDJView ? ' mine' : '') + (msg.isStaff ? ' staff' : '');
    div.innerHTML = `
      <div class="chat-msg-av${msg.isStaff ? ' staff' : ''}">${msg.avatar}</div>
      <div>
        <div class="chat-msg-name${msg.isStaff ? ' staff-name' : ''}">${msg.user}</div>
        <div class="chat-msg-bubble">${msg.text}</div>
      </div>
    `;
    return div;
  }

  function sendPublic() {
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text) return;
    const msg = { id: Date.now(), text, user: 'Tu', avatar: '👤' };
    _messages.push(msg);
    renderPublic();
    renderDJ();
    input.value = '';
    addActivity('💬', `Nuovo messaggio: "${text.slice(0,30)}${text.length > 30 ? '...' : ''}"`, 'icon-chat');
  }

  function sendDJ() {
    const input = document.getElementById('dj-chat-input');
    const text = input.value.trim();
    if (!text) return;
    const dj = Auth.getDJ();
    const msg = { id: Date.now(), text, user: dj?.display_name || 'DJ', avatar: '🎙️', isStaff: true };
    _messages.push(msg);
    renderPublic();
    renderDJ();
    input.value = '';
  }

  function addActivity(icon, text, iconClass) {
    const log = document.getElementById('activity-log');
    if (!log) return;
    const now = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
    const div = document.createElement('div');
    div.className = 'activity-item';
    div.innerHTML = `
      <div class="activity-icon ${iconClass}">${icon}</div>
      <div>
        <div class="activity-text">${text}</div>
        <div class="activity-time">${now}</div>
      </div>
    `;
    log.insertBefore(div, log.firstChild);
  }

  return { init, addActivity };

})();

// Funzione pubblica per benvenuto in chat al login
Chat.welcomeUser = function(name) {
  const msg = {
    id: Date.now(),
    text: '👋 Benvenuto/a ' + name + '! Ora puoi salvare i tuoi brani preferiti con ❤️',
    user: 'Radio Vinile',
    avatar: '📻',
    isStaff: true
  };
  Chat._messages = Chat._messages || [];
  // Accediamo ai messaggi tramite una funzione
  const container = document.getElementById('chat-messages');
  if (container) {
    const div = document.createElement('div');
    div.className = 'chat-msg staff';
    div.innerHTML = '<div class="chat-msg-av staff">📻</div><div><div class="chat-msg-name staff-name">Radio Vinile</div><div class="chat-msg-bubble">' + msg.text + '</div></div>';
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  }
};
