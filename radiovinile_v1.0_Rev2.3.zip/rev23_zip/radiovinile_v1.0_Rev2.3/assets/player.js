/* RADIO VINILE — player.js — v1.0 Rev 2.3
   Fix: timer al click, volume drag, condividi 💿, formato titolo, cuore
*/
const Player = (() => {
  const STREAM_URL = 'https://radiovinile.online/stream';
  const ICECAST_STATUS = 'https://stream.radiovinile.online/status-json.xsl';
  const POLL_INTERVAL = 10000;
  let _audio = null, _playing = false, _loading = false, _liked = false;
  let _volume = 0.8, _startTime = null, _timerInterval = null;
  let _nowPlaying = { title: 'In onda...', artist: '', year: '' };
  // FIX: contatore errori consecutivi per mostrare stato "stream offline"
  let _failCount = 0;

  function init() {
    _audio = document.getElementById('radio-audio');
    _audio.volume = _volume;

    _audio.addEventListener('playing', () => {
      _loading = false; _playing = true;
      updatePlayBtn(); setVinylSpin(true); setStreamStatus(true); hideStreamError();
    });
    _audio.addEventListener('pause', () => { _playing = false; updatePlayBtn(); setVinylSpin(false); stopTimer(); });
    _audio.addEventListener('waiting', () => { _loading = true; updatePlayBtn(); });
    _audio.addEventListener('error', () => {
      _loading = false; _playing = false;
      updatePlayBtn(); setVinylSpin(false); setStreamStatus(false); showStreamError(); stopTimer();
    });

    document.getElementById('btn-play').addEventListener('click', togglePlay);
    document.getElementById('hero-play-btn').addEventListener('click', () => {
      play(); document.getElementById('player').scrollIntoView({ behavior: 'smooth' });
    });

    // Cuore
    const likeBtn = document.getElementById('btn-like');
    if (likeBtn) likeBtn.addEventListener('click', () => {
      if (typeof ListenerAuth === 'undefined') return;
      if (!ListenerAuth.isLoggedIn()) {
        document.getElementById('listener-login-modal').classList.remove('hidden');
      } else {
        _liked = !_liked;
        likeBtn.textContent = _liked ? 'a' : 'o';
        likeBtn.classList.toggle('liked', _liked);
        if (_liked) { ListenerAuth.saveFavorite(_nowPlaying); App.showToast('Salvato nei preferiti!'); }
        else        { ListenerAuth.removeFavorite(_nowPlaying); App.showToast('Rimosso dai preferiti'); }
      }
    });

    // Condividi con vinile
    const shareBtn = document.getElementById('btn-share');
    if (shareBtn) shareBtn.addEventListener('click', () => {
      const np = _nowPlaying;
      const yr = np.year ? "'" + String(np.year).slice(-2) + ' - ' : '';
      const text = '💿 ' + yr + np.artist + ' - ' + np.title + ' | Radio Vinile\nhttps://radiovinile.online';
      if (navigator.share) navigator.share({ title: 'Radio Vinile 💿', text, url: 'https://radiovinile.online' });
      else navigator.clipboard.writeText(text).then(() => App.showToast('💿 Copiato!'));
    });

    initVolume();
    const vf = document.getElementById('vol-fill');
    if (vf) vf.style.width = (_volume * 100) + '%';

    fetchNowPlaying();
    setInterval(fetchNowPlaying, POLL_INTERVAL);
  }

  function initVolume() {
    const volBar = document.querySelector('.vol-bar');
    const volFill = document.getElementById('vol-fill');
    if (!volBar || !volFill) return;
    const setVol = (clientX) => {
      const rect = volBar.getBoundingClientRect();
      const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      _volume = pct; _audio.volume = pct; volFill.style.width = (pct * 100) + '%';
    };
    let drag = false;
    volBar.addEventListener('mousedown', e => { drag = true; setVol(e.clientX); });
    window.addEventListener('mousemove', e => { if (drag) setVol(e.clientX); });
    window.addEventListener('mouseup', () => drag = false);
    volBar.addEventListener('click', e => setVol(e.clientX));
    volBar.addEventListener('touchstart', e => setVol(e.touches[0].clientX), { passive: true });
    volBar.addEventListener('touchmove', e => { e.preventDefault(); setVol(e.touches[0].clientX); }, { passive: false });
  }

  // Timer — parte al click play
  function startTimer() {
    stopTimer(); _startTime = Date.now();
    _timerInterval = setInterval(updateTimer, 1000); updateTimer();
  }
  function stopTimer() {
    if (_timerInterval) { clearInterval(_timerInterval); _timerInterval = null; }
    const cur = document.getElementById('time-current'); if (cur) cur.textContent = '0:00';
    const tot = document.getElementById('time-total');   if (tot) tot.textContent = '0:00';
    const fill = document.getElementById('progress-fill'); if (fill) fill.style.width = '0%';
  }
  function updateTimer() {
    if (!_startTime) return;
    const s = Math.floor((Date.now() - _startTime) / 1000);
    const cur = document.getElementById('time-current'); if (cur) cur.textContent = fmt(s);
    const tot = document.getElementById('time-total');   if (tot) tot.textContent = 'LIVE';
    const fill = document.getElementById('progress-fill');
    if (fill) fill.style.width = Math.min(100, (s % 240) / 240 * 100) + '%';
  }
  function fmt(s) { return Math.floor(s/60) + ':' + String(s%60).padStart(2,'0'); }

  function play() {
    if (_loading) return;
    if (!_audio.src || _audio.src === window.location.href) _audio.src = STREAM_URL;
    _loading = true; updatePlayBtn();
    // Timer parte subito al click
    startTimer();
    _audio.play().catch(() => {
      _loading = false; _playing = false;
      updatePlayBtn(); stopTimer(); showStreamError('Impossibile avviare lo stream. Riprova.');
    });
  }
  function pause() {
    _audio.pause(); _playing = false; _loading = false;
    updatePlayBtn(); setVinylSpin(false); setStreamStatus(false); stopTimer();
  }
  function togglePlay() { _playing ? pause() : play(); }

  function updatePlayBtn() {
    const icon = _loading ? 'x' : (_playing ? 'p' : 'y');
    const icons = { 'y': 'u', 'p': 'n', 'x': 'l' };
    const btn  = document.getElementById('btn-play');       if (btn)  btn.textContent = _loading ? '⏳' : (_playing ? '⏸' : '▶');
    const hero = document.getElementById('hero-play-btn');  if (hero) hero.textContent = _playing ? '⏸ In ascolto' : '▶ Ascolta ora';
    const dj   = document.getElementById('dj-play-btn');    if (dj)   dj.textContent  = _playing ? '⏸' : '▶';
  }
  function setVinylSpin(r) {
    ['hero-vinyl','player-disc','on-air-disc'].forEach(id => { const e = document.getElementById(id); if(e) e.style.animationPlayState = r?'running':'paused'; });
  }
  function setStreamStatus(online) {
    const el = document.getElementById('ver-stream-status'); if (!el) return;
    el.textContent = online ? '🔴 In onda' : '⏸ Stream offline';
    el.style.color = online ? 'var(--live)' : 'var(--t3)';
  }
  function showStreamError(msg) {
    let el = document.getElementById('stream-error-banner');
    if (!el) { el = document.createElement('div'); el.id='stream-error-banner'; el.className='stream-error-banner'; const pw=document.querySelector('.player-wrap'); if(pw) pw.insertBefore(el,pw.firstChild); }
    el.textContent = msg || '⚠️ Stream non disponibile — riprova tra qualche secondo';
    el.classList.remove('hidden');
  }
  function hideStreamError() { const el=document.getElementById('stream-error-banner'); if(el) el.classList.add('hidden'); }

  async function fetchNowPlaying() {
    try {
      // Legge da Icecast per avere i tag ICY (titolo, artista)
      const res  = await fetch(ICECAST_STATUS);
      const data = await res.json();
      const src  = data?.icestats?.source;
      if (!src) return;

      // FIX: Liquidsoap invia il campo ICY "song" come "Artista - Titolo"
      // Se map_metadata è configurato, il nome file yt-dlp può dare "ANNO - Artista - Titolo"
      // Gestisce entrambi i formati: 3 parti (con anno) e 2 parti (senza anno)
      const raw   = src.title || '';
      const parts = raw.split(' - ');

      let year, artist, title;

      if (parts.length >= 3 && /^\d{4}$/.test(parts[0].trim())) {
        // Formato "ANNO - Artista - Titolo" — anno nel primo segmento
        year   = parts[0].trim();
        artist = parts[1].trim();
        title  = parts.slice(2).join(' - ').trim();
      } else if (parts.length >= 2) {
        // Formato standard "Artista - Titolo"
        // FIX: src.year non esiste in status-json.xsl — Icecast non lo espone
        // Se map_metadata in radio.liq è configurato, l'anno è già nel campo song
        year   = '';
        artist = parts[0].trim();
        title  = parts.slice(1).join(' - ').trim();
      } else {
        // Fallback: nessun separatore
        year   = '';
        artist = 'Radio Vinile';
        title  = raw || 'In onda...';
      }

      const count = src.listeners || 0;
      _nowPlaying = { title, artist, year };
      _failCount  = 0; // reset contatore errori

      // Formato: '84 · Vasco Rossi · Vita spericolata
      const yr    = year ? "'" + String(year).slice(-2) + ' · ' : '';
      const label = yr + artist + ' · ' + title;

      const set = (id,v) => { const e=document.getElementById(id); if(e) e.textContent=v; };
      set('player-title',    label);
      set('player-artist',   '');
      set('live-strip-song', artist ? artist + ' — ' + title : title);
      set('listener-count',  count);
      set('oa-title',        title);
      set('oa-artist',       artist);

      if (typeof ListenerAuth !== 'undefined' && ListenerAuth.isLoggedIn()) {
        const isFav = ListenerAuth.getFavorites().some(f => f.title===title && f.artist===artist);
        const btn = document.getElementById('btn-like');
        if (btn) { _liked=isFav; btn.textContent=isFav?'❤️':'♥'; btn.classList.toggle('liked',isFav); }
      }
    } catch(_) {
      // FIX: catch silenzioso rimosso — mostra "stream offline" dopo 3 errori consecutivi
      _failCount++;
      if (_failCount >= 3) {
        setStreamStatus(false);
        const set = (id,v) => { const e=document.getElementById(id); if(e) e.textContent=v; };
        set('player-title', '⚠️ Stream non disponibile');
      }
    }
  }

  // FIX: handleLike() — chiamato da listener-auth.js dopo login per salvare il brano corrente
  // Era mancante dal public API: listener-auth.js riga 95 chiama Player.handleLike()
  function handleLike() {
    if (typeof ListenerAuth === 'undefined' || !ListenerAuth.isLoggedIn()) return;
    if (_liked) return;
    _liked = true;
    const likeBtn = document.getElementById('btn-like');
    if (likeBtn) {
      likeBtn.textContent = '❤️';
      likeBtn.classList.add('liked');
    }
    ListenerAuth.saveFavorite(_nowPlaying);
    if (typeof App !== 'undefined') App.showToast('Salvato nei preferiti!');
  }

  function isPlaying()     { return _playing; }
  function getNowPlaying() { return _nowPlaying; }
  // FIX: handleLike aggiunto al public API
  return { init, play, pause, togglePlay, fetchNowPlaying, isPlaying, getNowPlaying, handleLike };
})();
