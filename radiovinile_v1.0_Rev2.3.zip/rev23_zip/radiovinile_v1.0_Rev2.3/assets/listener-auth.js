/* ════════════════════════════════════════════════════
   RADIO VINILE — listener-auth.js
   Login ascoltatori via Google OAuth REALE
   Versione: v1.0 Rev 1.9
════════════════════════════════════════════════════ */

const ListenerAuth = (() => {

  const TOKEN_KEY = 'rv_listener_token';
  const USER_KEY  = 'rv_listener';
  const FAVS_KEY  = 'rv_favorites';
  const API       = 'https://api.radiovinile.online/api';

  let _token = localStorage.getItem(TOKEN_KEY);
  let _user  = JSON.parse(localStorage.getItem(USER_KEY) || 'null');

  function init() {
    // Controlla se torniamo dal callback Google con token nell'URL
    const urlParams   = new URLSearchParams(window.location.search);
    const rvToken     = urlParams.get('rv_token');
    const loginResult = urlParams.get('login');

    if (rvToken && loginResult === 'success') {
      _token = rvToken;
      localStorage.setItem(TOKEN_KEY, _token);
      window.history.replaceState({}, '', window.location.pathname);
      loadProfile().then(() => {
        _updateNavUI();
        if (typeof App !== 'undefined') App.showToast('Benvenuto/a ' + (_user?.display_name || '') + '! 🎵');
        if (typeof Chat !== 'undefined' && Chat.welcomeUser) Chat.welcomeUser(_user?.display_name || '');
        if (typeof Player !== 'undefined' && Player.handleLike) Player.handleLike();
      });
    } else if (loginResult === 'error') {
      window.history.replaceState({}, '', window.location.pathname);
      if (typeof App !== 'undefined') App.showToast('❌ Login fallito. Riprova.');
    }

    // Bottoni modal
    const googleBtn = document.getElementById('login-google-btn');
    const fbBtn     = document.getElementById('login-facebook-btn');
    const emailBtn  = document.getElementById('login-email-btn');
    const closeBtn  = document.getElementById('listener-login-close');
    if (googleBtn) googleBtn.addEventListener('click', loginWithGoogle);
    if (fbBtn)     fbBtn.addEventListener('click', loginWithFacebook);
    if (emailBtn)  emailBtn.addEventListener('click', loginWithEmail);
    if (closeBtn)  closeBtn.addEventListener('click', () =>
      document.getElementById('listener-login-modal').classList.add('hidden'));

    const modal = document.getElementById('listener-login-modal');
    if (modal) modal.addEventListener('click', e => {
      if (e.target === modal) modal.classList.add('hidden');
    });

    const favsBtn = document.getElementById('nav-favorites-btn');
    if (favsBtn) favsBtn.addEventListener('click', showFavorites);

    const logoutBtn = document.getElementById('nav-listener-logout');
    if (logoutBtn) logoutBtn.addEventListener('click', () => {
      logout();
      if (typeof App !== 'undefined') App.showToast('Disconnesso');
    });

    const favsClose = document.getElementById('favorites-close');
    if (favsClose) favsClose.addEventListener('click', () =>
      document.getElementById('favorites-modal').classList.add('hidden'));

    if (_user) _updateNavUI();
  }

  function loginWithGoogle() {
    window.location.href = 'https://radiovinile.online/auth/google/login';
  }

  function loginWithFacebook() {
    if (typeof App !== 'undefined') App.showToast('Facebook Login — disponibile presto!');
  }

  function loginWithEmail() {
    const email = prompt('Inserisci la tua email:');
    if (!email || !email.includes('@')) return;
    const name = email.split('@')[0];
    _setUser({ display_name: name, email, avatar_url: '', provider: 'email' });
    document.getElementById('listener-login-modal').classList.add('hidden');
    _updateNavUI();
    if (typeof App !== 'undefined') App.showToast('Benvenuto/a ' + name + '!');
  }

  async function loadProfile() {
    if (!_token) return;
    try {
      const res = await fetch(API + '/auth/me', {
        headers: { 'Authorization': 'Bearer ' + _token }
      });
      if (!res.ok) { logout(); return; }
      const data = await res.json();
      _setUser(data);
    } catch (_) {}
  }

  function _setUser(user) {
    _user = user;
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function logout() {
    _token = null; _user = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    _updateNavUI();
  }

  function _updateNavUI() {
    const info   = document.getElementById('nav-listener-info');
    const nameEl = document.getElementById('nav-listener-name');
    if (!info) return;
    if (_user) {
      info.classList.remove('hidden');
      if (nameEl) nameEl.textContent = _user.display_name || _user.name || '';
    } else {
      info.classList.add('hidden');
    }
  }

  function getFavorites() {
    return JSON.parse(localStorage.getItem(FAVS_KEY) || '[]');
  }

  async function saveFavorite(track) {
    const favs   = getFavorites();
    const exists = favs.some(f => f.title === track.title && f.artist === track.artist);
    if (!exists) {
      favs.unshift({ ...track, savedAt: new Date().toISOString() });
      localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    }
    if (_token) {
      try {
        await fetch(API + '/favorites', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + _token, 'Content-Type': 'application/json' },
          body: JSON.stringify({ song_title: track.title, song_artist: track.artist, song_year: track.year || '' })
        });
      } catch (_) {}
    }
  }

  function removeFavorite(track) {
    const favs = getFavorites().filter(f => !(f.title === track.title && f.artist === track.artist));
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
  }

  function removeFavoriteByIndex(index) {
    const favs = getFavorites();
    favs.splice(index, 1);
    localStorage.setItem(FAVS_KEY, JSON.stringify(favs));
    showFavorites();
    if (typeof App !== 'undefined') App.showToast('Rimosso dai preferiti');
  }

  function showFavorites() {
    const modal = document.getElementById('favorites-modal');
    const list  = document.getElementById('favorites-list');
    const empty = document.getElementById('favorites-empty');
    const favs  = getFavorites();
    if (!modal || !list) return;
    if (!favs.length) {
      list.innerHTML = '';
      if (empty) empty.classList.remove('hidden');
    } else {
      if (empty) empty.classList.add('hidden');
      list.innerHTML = favs.map((f, i) => `
        <div class="fav-item">
          <div class="fav-disc">🎵</div>
          <div class="fav-info">
            <div class="fav-title">${f.title}</div>
            <div class="fav-artist">${f.artist || ''}${f.year ? ' · ' + f.year : ''}</div>
            <div class="fav-date">${f.savedAt ? new Date(f.savedAt).toLocaleDateString('it-IT') : ''}</div>
          </div>
          <button class="fav-remove" onclick="ListenerAuth.removeFavoriteByIndex(${i})">✕</button>
        </div>
      `).join('');
    }
    modal.classList.remove('hidden');
  }

  function getUser()    { return _user; }
  function getToken()   { return _token; }
  function isLoggedIn() { return !!_token && !!_user; }

  return {
    init, getUser, getToken, isLoggedIn,
    getFavorites, saveFavorite, removeFavorite, removeFavoriteByIndex,
    showFavorites, loginWithGoogle, loginWithFacebook, logout, loadProfile
  };

})();
