#!/bin/bash
# ================================================================================
# RADIO VINILE — download_music.sh
# Scarica una playlist YouTube e converte in MP3 con tag ID3 corretti.
# Versione: v1.0 Rev 2.3
#
# Uso: ./download_music.sh <URL_playlist> <70s|80s|90s>
# Esempio: ./download_music.sh "https://youtube.com/playlist?list=PLxxx" 80s
#
# Fix Rev 2.3:
#   - Aggiunto --yes-playlist per forzare download di tutta la playlist
#   - Aggiunto --no-abort-on-error per continuare in caso di video bloccati
#   - Formato output include %(upload_date)s per evitare sovrascritture
#   - Aggiunto --sleep-interval per rispettare rate limit YouTube
#   - Aggiunto --extractor-args per ridurre richieste bot-detection
#   - Aggiunto --no-check-certificates per ambienti server
#   - Output rinominato: "NA - Artista - Titolo.mp3" (fix_id3_tags.py lo processa)
# ================================================================================

URL="$1"
DECADE="${2:-80s}"
MUSIC_DIR="/opt/radiovinile/music/$DECADE"
LOG_FILE="/tmp/dl_$(date +%Y%m%d_%H%M%S).log"

if [ -z "$URL" ]; then
    echo "Uso: $0 <URL_playlist_o_video> <70s|80s|90s>"
    echo "Esempio: $0 'https://youtube.com/playlist?list=PLxxx' 80s"
    exit 1
fi

mkdir -p "$MUSIC_DIR"
echo "🎵 Download in $MUSIC_DIR..."
echo "📋 Log: $LOG_FILE"
echo "🔗 URL: $URL"

# Conta brani esistenti prima
BEFORE=$(ls "$MUSIC_DIR"/*.mp3 2>/dev/null | wc -l)

yt-dlp \
    --yes-playlist \
    --no-abort-on-error \
    --ignore-errors \
    -x \
    --audio-format mp3 \
    --audio-quality 192K \
    --add-metadata \
    --no-embed-thumbnail \
    --sleep-interval 1 \
    --max-sleep-interval 3 \
    --no-check-certificates \
    --extractor-args "youtube:player_client=android" \
    -o "$MUSIC_DIR/NA - %(uploader)s - %(title)s.%(ext)s" \
    --restrict-filenames \
    2>&1 | tee "$LOG_FILE" \
    "$URL"

# Conta brani scaricati
AFTER=$(ls "$MUSIC_DIR"/*.mp3 2>/dev/null | wc -l)
NEW=$((AFTER - BEFORE))

echo ""
echo "📊 Risultato download:"
echo "   Brani prima: $BEFORE"
echo "   Brani dopo:  $AFTER"
echo "   Nuovi:       $NEW"
echo ""

if [ "$NEW" -gt 0 ]; then
    echo "🔧 Fix tag ID3 sui nuovi brani..."
    python3 /opt/radiovinile/fix_id3_tags.py --dir "$MUSIC_DIR"
else
    echo "⚠️  Nessun nuovo brano scaricato. Controlla il log: $LOG_FILE"
fi

echo "✅ Fatto! Brani totali in $MUSIC_DIR: $(ls "$MUSIC_DIR"/*.mp3 2>/dev/null | wc -l)"
echo "📋 Log completo: $LOG_FILE"
