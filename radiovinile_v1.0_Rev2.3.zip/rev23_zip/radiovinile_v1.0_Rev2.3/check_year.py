#!/usr/bin/env python3
"""
================================================================================
RADIO VINILE — check_year.py
Filtro anni per Liquidsoap — verifica che il brano sia degli anni 70/80/90
Chiamato da radio.liq prima di ogni brano.
Restituisce exit code 0 se OK, 1 se da saltare.
================================================================================
"""
import sys, re, os
from mutagen.id3 import ID3

fpath = sys.argv[1] if len(sys.argv) > 1 else ""
if not fpath or not os.path.exists(fpath):
    sys.exit(0)

try:
    tags  = ID3(fpath)
    tdrc  = str(tags.get('TDRC', ''))
    year  = int(tdrc[:4]) if len(tdrc) >= 4 else 0

    # Se anno > 1999 nei tag (data upload YouTube), ignora e cerca nel nome file
    if year == 0 or year > 1999:
        fname = os.path.basename(fpath)
        m = re.search(r'\b(19[6-9]\d)\b', fname)
        year = int(m.group(1)) if m else 0

    if 1965 <= year <= 1999:
        sys.exit(0)   # ✅ Anni 70/80/90 — manda in onda
    elif year == 0:
        sys.exit(0)   # ✅ Anno sconosciuto — lascia passare
    else:
        sys.stderr.write(f"SKIP: {os.path.basename(fpath)} (anno {year})\n")
        sys.exit(1)   # ❌ Fuori periodo — salta
except Exception:
    sys.exit(0)       # In caso di errore lascia passare
