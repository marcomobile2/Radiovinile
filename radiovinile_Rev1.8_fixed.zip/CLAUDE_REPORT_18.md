# CLAUDE_REPORT_18 — Radio Vinile Rev 1.8
**Data analisi:** 2026-03-23
**File analizzati:** `radio.liq`, `player.js`, `listener-auth.js`
**File prodotti:** `radio_fixed_18.liq`, `player_fixed_18.js`

---

## 1. Bug trovati

| # | File | Riga | Gravità | Descrizione |
|---|------|------|---------|-------------|
| 1 | `radio.liq` | 50–61 | 🔴 | Nessun `map_metadata` — il campo ICY `song` non viene costruito, Icecast riceve frame senza metadati |
| 2 | `radio.liq` | 50–61 | 🔴 | `send_icy_metadata=true` assente in `output.icecast` — in Liquidsoap 2.2 non è garantito come default per MP3 |
| 3 | `player.js` | 157 | 🔴 | `src.year` non esiste: Icecast `status-json.xsl` non espone il campo `year`, sarà sempre `""` |
| 4 | `player.js` | 154–156 | 🟠 | Parsing `src.title` gestisce solo 2 parti (`Artista - Titolo`), non 3 (`ANNO - Artista - Titolo`) |
| 5 | `player.js` | 179 | 🟠 | `catch(_) {}` silenzioso — nessun feedback all'utente se l'API Icecast è irraggiungibile |
| 6 | `player.js` | 184 | 🔴 | `handleLike` non esportato nel public API di `Player` ma chiamato da `listener-auth.js` riga 95 |
| 7 | `listener-auth.js` | 95 | 🔴 | `Player.handleLike()` chiamato dopo login ma la funzione non è mai stata dichiarata/esportata → crash runtime `TypeError: Player.handleLike is not a function` |
| 8 | `player.js` | 51 | 🟡 | Formato `condividi`: usa `' - '` invece di `' · '` — inconsistenza con il formato display `'84 · Vasco · Titolo` |

---

## 2. Spiegazione tecnica del flusso metadata

```
[File MP3 su disco]
  → tag ID3: TITLE="Vita spericolata", ARTIST="Vasco Rossi", DATE="1983"
  → yt-dlp scarica con nome file: "1983 - Vasco Rossi - Vita spericolata.mp3"
        ↓
[Liquidsoap 2.2 — playlist()]
  → legge tag ID3 → normalizza in minuscolo: title, artist, date
  → espone anche: filename = "/opt/suimi/.../1983 - Vasco Rossi - Vita spericolata.mp3"
        ↓
[BUG ORIGINALE: nessun map_metadata]
  → il frame audio non ha il campo "song" nell'header ICY
  → output.icecast senza send_icy_metadata=true potrebbe non iniettare ICY metadata
        ↓
[Icecast2]
  → riceve frame senza campo ICY "song"
  → status-json.xsl restituisce: "title": "" (o assente)
  → NON espone mai il campo "year"
        ↓
[player.js — fetchNowPlaying()]
  → src.title = "" → label = "Radio Vinile" (fallback)
  → src.year = undefined → year = ""
  → utente vede: "In onda..." invece di "'83 · Vasco Rossi · Vita spericolata"
```

**Con i fix applicati:**
```
[map_metadata in radio.liq]
  → costruisce: song = "Vasco Rossi - Vita spericolata"
  → estrae year = "1983" dal nome file via regex "(\\d{4}) - "
  → costruisce rv_label = "'83 · Vasco Rossi · Vita spericolata" (uso interno)
        ↓
[output.icecast con send_icy_metadata=true]
  → inietta ICY header: StreamTitle='Vasco Rossi - Vita spericolata'
        ↓
[Icecast2 → status-json.xsl]
  → "title": "Vasco Rossi - Vita spericolata"
        ↓
[player.js — fetchNowPlaying() FIX]
  → parts = ["Vasco Rossi", "Vita spericolata"] → 2 parti → artist/title corretti
  → oppure parts = ["1983", "Vasco Rossi", "Vita spericolata"] → 3 parti → year estratto
```

---

## 3. Modifiche applicate in `radio_fixed_18.liq`

### 3.1 Aggiunto blocco `map_metadata`
Inserito dopo `radio = fallback(track_sensitive=false, [live, radio])` e prima di `output.icecast`:

```liquidsoap
radio = map_metadata(fun(m) ->
  let title  = m["title"]
  let artist = m["artist"]
  let fname  = m["filename"]
  let year_matches = string.extract(pattern="(\\d{4}) - ", fname)
  let year =
    if year_matches != [] then
      list.assoc(default="", "1", year_matches)
    else
      string.sub(m["date"], start=0, length=4)
    end
  let yy       = string.sub(year, start=2, length=2)
  let rv_label = "'" ^ yy ^ " · " ^ artist ^ " · " ^ title
  [("song",     artist ^ " - " ^ title),
   ("year",     year),
   ("rv_label", rv_label),
   ("title",    title),
   ("artist",   artist)]
end, radio)
```

**Logica estrazione anno:**
- `string.extract(pattern="(\\d{4}) - ", fname)` cerca il pattern `YYYY - ` ovunque nel percorso file
- Cattura il primo gruppo `(\\d{4})` — restituisce lista `[("1", "1983")]`
- `list.assoc("1", year_matches)` estrae il valore del primo gruppo
- Fallback: `m["date"]` (campo ID3 DATE, troncato a 4 char)

### 3.2 Aggiunto `send_icy_metadata=true` in `output.icecast`
```liquidsoap
output.icecast(
  ...
  send_icy_metadata=true,
  radio
)
```

### 3.3 Impostazioni invariate
Porta 8950, password `rv_source_2026`, mount `/stream`, commento header v1.6 FIXED — tutto invariato.

---

## 4. Modifiche applicate in `player_fixed_18.js`

### 4.1 Aggiunto `_failCount`
```javascript
let _failCount = 0;
```
Contatore errori consecutivi in `fetchNowPlaying`.

### 4.2 Fix parsing `src.title` in `fetchNowPlaying()`
Sostituisce il vecchio parsing a 2 parti con logica che gestisce entrambi i formati:

```javascript
const parts = raw.split(' - ');

if (parts.length >= 3 && /^\d{4}$/.test(parts[0].trim())) {
  // "ANNO - Artista - Titolo" — anno nel primo segmento
  year   = parts[0].trim();
  artist = parts[1].trim();
  title  = parts.slice(2).join(' - ').trim();
} else if (parts.length >= 2) {
  // "Artista - Titolo" — formato standard ICY
  year   = '';
  artist = parts[0].trim();
  title  = parts.slice(1).join(' - ').trim();
} else {
  year = ''; artist = 'Radio Vinile'; title = raw || 'In onda...';
}
```

### 4.3 Rimosso `src.year`
`src.year` non esiste in `status-json.xsl`. Icecast espone solo: `title`, `description`, `genre`, `listeners`, `listenurl`, `audio_info`. Il campo `year` viene ora estratto dal parsing del campo `title` (se nel formato 3 parti).

### 4.4 Fix `catch` silenzioso
```javascript
} catch(_) {
  _failCount++;
  if (_failCount >= 3) {
    setStreamStatus(false);
    set('player-title', '⚠️ Stream non disponibile');
  }
}
```
Dopo 3 errori consecutivi viene mostrato lo stato "stream offline" nel player. `_failCount` viene azzerato a `0` ad ogni fetch riuscita.

### 4.5 Aggiunta funzione `handleLike()`
```javascript
function handleLike() {
  if (typeof ListenerAuth === 'undefined' || !ListenerAuth.isLoggedIn()) return;
  if (_liked) return;
  _liked = true;
  const likeBtn = document.getElementById('btn-like');
  if (likeBtn) { likeBtn.textContent = '❤️'; likeBtn.classList.add('liked'); }
  ListenerAuth.saveFavorite(_nowPlaying);
  if (typeof App !== 'undefined') App.showToast('Salvato nei preferiti!');
}
```
Aggiunta anche al `return` pubblico:
```javascript
return { init, play, pause, togglePlay, fetchNowPlaying, isPlaying, getNowPlaying, handleLike };
```

---

## 5. Bug aggiuntivi trovati

### Bug #6/#7 — `Player.handleLike()` — CRITICO 🔴
**File:** `listener-auth.js:95` + `player.js:184`

`_onLoginSuccess()` in `listener-auth.js` chiama:
```javascript
Player.handleLike();
```
Ma nel `player.js` originale, `handleLike` non è mai stata definita né esportata.
**Effetto:** ogni volta che un utente fa login tramite Google/Facebook/Email mentre è in ascolto → `TypeError: Player.handleLike is not a function` → console error + l'azione "like automatico post-login" non funziona.

### Bug #8 — Formato `condividi` inconsistente 🟡
**File:** `player.js:51`
La funzione `condividi` usa `"'" + year + ' - '` (trattino), mentre il display usa `'·'` (punto medio). Formato coerente non applicato nel testo di condivisione.

### Bug aggiuntivo — `listener-auth.js:190` — `loginWithEmail` non esportata 🟡
```javascript
return { init, getUser, isLoggedIn, getFavorites, saveFavorite, removeFavorite,
         removeFavoriteByIndex, logout, showFavorites, loginWithGoogle, loginWithFacebook };
```
`loginWithEmail` è definita ma non esportata. Se un componente esterno tenta di chiamarla → `undefined`.

---

## 6. Suggerimenti di miglioramento prioritizzati

### P0 — Bloccante in produzione

- **CORS su Icecast:** `fetch(ICECAST_STATUS)` può fallire per policy CORS se Icecast2 non ha `Access-Control-Allow-Origin: *` nel suo `icecast.xml`. Soluzione consigliata: aggiungere un endpoint proxy lato FastAPI (`/api/nowplaying`) che fa la fetch server-side e la restituisce al browser.

- **`handleLike` mancante** (già fixato in `player_fixed_18.js`): crash runtime ad ogni login ascoltatore.

### P1 — Alta priorità

- **Proxy API `/api/nowplaying`:** Implementare in FastAPI un endpoint che interroga `http://localhost:8950/status-json.xsl` e restituisce i dati normalizzati. Elimina problemi CORS, riduce la dipendenza dal formato di Icecast, permette cache lato server.

- **`map_metadata` su sorgente live DJ:** Attualmente `map_metadata` è applicato a `radio` dopo il `fallback([live, radio])`, quindi include anche lo stream live BUTT. Verificare che i metadati ICY inviati da BUTT non vengano sovrascritti erroneamente.

- **Telnet Liquidsoap senza autenticazione:** La porta 1234 è aperta senza password (`settings.server.telnet := true`). Se accessibile da rete esterna, permette controllo completo di Liquidsoap. Aggiungere `settings.server.telnet.bind_addr := "127.0.0.1"`.

### P2 — Media priorità

- **`loginWithEmail` non esportata** in `listener-auth.js`: aggiungere al `return`.
- **Formato condividi:** uniformare al formato `'84 · Artista · Titolo` anche nel testo degli share.
- **`_nowPlaying` iniziale:** Al primo caricamento prima del fetch, mostrare "Caricamento..." anziché "In onda..." per distinguere lo stato "non ancora caricato" da "in onda senza metadati".
- **`string.extract` fallback:** Se `m["date"]` è vuoto, `string.sub(m["date"], start=0, length=4)` restituisce `""`. Aggiungere fallback a `""` esplicito è già corretto, ma loggare un warning Liquidsoap aiuterebbe il debug.

### P3 — Bassa priorità / Miglioramenti futuri

- **Integrazione Firebase Auth reale** al posto della simulazione in `_simulateLogin()`.
- **Persistenza preferiti lato server** invece di `localStorage` (si perde al cambio browser/dispositivo).
- **WebSocket o SSE** per aggiornamenti metadata real-time invece di polling ogni 10s.
- **`rv_label` come campo ICY personalizzato:** Icecast non esponde campi custom nel JSON status, ma potrebbe essere usato dal DJ panel o da una API interna per il display dashboard.
- **Gestione titoli con trattini multipli:** Es. `"Guns N' Roses - Sweet Child O' Mine - Live"` — il `.slice(1).join(' - ')` già gestisce questo caso correttamente nel fix.
